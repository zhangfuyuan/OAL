/* eslint valid-jsdoc: "off" */

'use strict';

const path = require('path');
/**
 * @param {Egg.EggAppInfo} appInfo app info
 */
module.exports = appInfo => {
  /**
   * built-in config
   * @type {Egg.EggAppConfig}
   **/
  const config = exports = {};

  // use for cookie sign key, should change to your own and keep security
  config.keys = appInfo.name + '_1568877255815_9242';

  // add your middleware config here
  config.middleware = [];

  // add your user config here
  const userConfig = {
    // myAppName: 'egg',
  };

  config.jwt = {
    secret: 'oalmaster@2020',
  };

  config.security = {
    csrf: {
      enable: false,
    },
    domainWhiteList: [ '*' ],
  };
  config.view = {
    root: path.join(appInfo.baseDir, 'app/public'),
    mapping: {
      '.html': 'nunjucks',
      '.js': 'app/public',
      '.css': 'app/public',
    },
  };

  config.mongoose = {
    // 172.17.0.1
    // url: `mongodb://172.17.0.1:27017/${process.env.dbName}`,
    url: 'mongodb://127.0.0.1:27017/guarder',
    // url: 'mongodb://10.11.4.167:27017/guarder',
    options: { useUnifiedTopology: true },
  };

  config.multipart = {
    whitelist: [
      '.jpg', '.jpeg', // image/jpeg
      '.png',
      '.zip',
    ],
    fileSize: '500mb',
  };

  config.io = {
    init: { cookie: false },
    namespace: {
      '/': {
        connectionMiddleware: [ 'connection' ],
        packetMiddleware: [ 'packet' ],
      },
    },
    redis: {
      host: '10.11.4.167',
      port: 6379,
      password: '',
      db: 0,
    },
  };

  config.cors = {
    origin: '*',
    credentials: true,
    allowMethods: 'GET,HEAD,PUT,POST,DELETE,PATCH,OPTIONS',
  };

  config.weed = {
    server: '127.0.0.1',
    port: 9333,
    masters: [
      {
        host: '127.0.0.1',
        port: 9333,
      },
    ],
    scheme: 'http',
  };

  config.mqMaxSendCount = 100; // 消息队列中最大投递次数，如果大于这个次数就丢弃消息

  return {
    ...config,
    ...userConfig,
  };
};
