'use strict';

const { clone } = require('lodash');
const { DEFAULT_ADMIN_USER, DEFAULT_ORG_PATH } = require('./constant');

class AppBootHook {
  constructor(app) {
    this.app = app;
  }
  async didReady() {
    console.log('-- guarder server is ready --');
    const ctx = await this.app.createAnonymousContext();
    const defaultOrg = await ctx.service.organization.getByPath(DEFAULT_ORG_PATH);
    console.log('defaultOrg is:', defaultOrg);
    if (!defaultOrg) {
      // 管理员账户还未被创建,创建管理员账户
      const newOrg = await ctx.service.organization.add({
        path: 'admin',
        type: 0,
      });
      let defaultUserBean = clone(DEFAULT_ADMIN_USER);
      defaultUserBean.org = newOrg._id;
      const newUser = await ctx.service.user.add(defaultUserBean);
      console.log('Added new user is:', newUser);
    }
  }
}
module.exports = AppBootHook;
