'use strict';

const md5 = require('md5');

const menuBean = (name, icon, path, scope) => {
  return {
    path,
    locale: `menu.${name}`,
    name,
    icon,
    scope,
  };
};

module.exports = Object.freeze({
  DEFAULT_ADMIN_USER: {
    userName: 'admin',
    password: '21232f297a57a5a743894a0e4a801fc3', // admin
    type: 0,
    profile: {
      nickName: '管理员',
    },
  },
  DEFAULT_USER_PASSWORD: md5('123456'),
  DEFAULT_ORG_PATH: 'admin', // 默认组织的路径
  AUTH_MAX_ERROR_COUNT: 5, // 认证错误最高次数
  FREEZING_TIME_AFTER_AUTH_ERROR: 5, // 认证错误后，账号冻结时长（分钟）
  AUTH_TOKEN_EXPIRES_TIME: 12000, // 认证token的失效时间(秒)
  AUTH_TOKEN_DEVICE_EXPIRES_TIME: 1200000000000, // 认证token的失效时间(秒)
  ROLES: {
    SYSTEM_USER: 'SYSTEM_USER', // 系统管理员
    ORG_ADMIN: 'ORG_ADMIN', // 组织管理员
  },
  MENUS: [
    menuBean('orgManger', 'idcard', '/org', [ 'adminOrg' ]),
    menuBean('userManagement', 'user', '/userManagement'),
    menuBean('device', 'hdd', '/device/pass'),
    menuBean('faceManger', 'smile', '/face'),
    menuBean('workAttendance', 'table', '/workAttendance'),
    menuBean('settings', 'setting', '/settings'),
  ],
});
