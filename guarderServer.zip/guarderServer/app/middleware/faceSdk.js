'use strict';

// const openailabfaceapi = require('../lib/aidfacesdk.node');

const faceSdk = {
    /**
     * 获取人脸特征值
     * type: 4 , 512, 512plus, 22
     */
    getFeature: (image, type = 4) => {
        if (type === 4) {
            // return openailabfaceapi.FaceFeature(image)
        }
        // return openailabfaceapi.FaceFeature(image)
    },
}
module.exports = faceSdk;
