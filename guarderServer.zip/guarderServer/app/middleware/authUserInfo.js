'use strict';

const errorCode = require('../errorCode');

module.exports = options => {
  return async function(ctx, next) {
    let authUser;
    if (ctx.state.user.type === 'device') {
      // 设备调用
      authUser = await ctx.service.device.queryOne({ _id: ctx.state.user._id, org: ctx.state.user.orgInfo });
      console.log('authUser-----', authUser);
      if (!authUser || authUser.state === 0) {
        ctx.body = errorCode.QUERY_DATA_NO_FOUND;
        return;
      }
      if (authUser.verify !== 1) {
        // 不是一个已经通过审核的设备
        ctx.body = errorCode.DEVICE_NOT_APPROVED_YET;
        return;
      }
    } else if (ctx.state.user.type === 'platform') {
      // 第三方平台调用。使用开发者账号
      authUser = await ctx.service.developer.queryOne({ _id: ctx.state.user._id });
      if (ctx.state.user.secretVersion !== authUser.secretVersion) {
        // 密钥版本已经不同
        ctx.body = errorCode.AUTH_USER_INVALID_ACCESS_TOKEN;
        return;
      }
    } else {
      // 用户调用
      const queryData = {
        userId: ctx.state.user._id,
      };
      if (options && options.psw) {
        queryData.psw = true;
      }
      authUser = await ctx.service.user.getDetialById(queryData);
      if (authUser && authUser.state !== 1) {
        // 失效或者冻结
        ctx.body = errorCode.AUTH_USER_NO_FOUND;
        return;
      }
    }
    // console.log('authUser**', authUser);
    if (authUser) {
      if (authUser.org.state === 0) {
        // 用户的所属组织已经失效
        ctx.body = errorCode.AUTH_USER_INVALID_ORG;
        return;
      }
      ctx.state.userInfo = authUser;
      await next();
    } else {
      ctx.body = errorCode.AUTH_USER_NO_FOUND;
    }
  };
};
