'use strict';

const errorCode = require('../errorCode');

module.exports = () => {
  return async function(ctx, next) {
    const deviceId = ctx.params.deviceId || ctx.request.body.deviceId;
    if (!deviceId) {
      ctx.body = errorCode.DATA_MISSING_PARAMETERS;
      return;
    }
    const deviceInfo = await ctx.service.device.queryOne({ _id: deviceId, org: ctx.state.userInfo.org._id });
    if (!deviceInfo || deviceInfo.state === 0) {
      ctx.body = errorCode.QUERY_DATA_NO_FOUND;
      return;
    }
    ctx.state.deviceInfo = deviceInfo;
    await next();
  };
};
