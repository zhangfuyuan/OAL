'use strict';

const errorCode = require('../errorCode');

module.exports = () => {
  return async function(ctx, next) {
    // console.log('ctx--------', ctx.req);
    // ctx.status = 416
    const configBean = await ctx.service.sysConfig.queryByOrg(ctx.state.user.orgId);
    if (!configBean || configBean.length === 0) {
      // 用户没做任何配置，默认不做限制
      console.log('---------用户没做任何配置，默认不做限制-----------');
      await next();
      return;
    }
    // console.log('configBean---->', configBean);
    let flag = true;
    for (let i = 0; i < configBean.length; i++) {
      if (configBean[i].key === 'maxFaceCount') {
        // 最大数量的限制
        const total = await ctx.model.Face.find({ org: ctx.state.user.orgId, state: 1 }).countDocuments();
        // console.log('total-----', total);
        if (total >= Number(configBean[i].value)) {
          flag = false;
          break;
        }
      }
      if (configBean[i].key === 'faceSize') {
        // 图片的尺寸限制
        // console.log('ctx.req._readableState.length----', ctx.get('Content-Length'));
        const orgSize = ctx.get('Content-Length') / 1024;
        // console.log('this size is:', orgSize, configBean[i].value);
        if ((orgSize < configBean[i].value.min) || (orgSize > configBean[i].value.max)) {
          // 不符合尺寸限制
          flag = false;
          break;
        }
      }
    }
    if (!flag) {
      ctx.body = errorCode.IMAGE_SIZE_IS_UNQUALIFIED;
      return;
    }
    await next();
  };
};
