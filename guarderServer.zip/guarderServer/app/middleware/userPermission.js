'use strict';
/**
 * 用户数据权限
 * @type {{DATA_UPDATE_ERROR_VERSION, RESPONE, AUTH_USER_INVALID_USER, QUERY_CONDITION_IS_EMPTY, AUTH_USER_ACCESS_TOKEN_EXPIRE, DATA_MISSING_PARAMETERS, QUERY_CONDITION_MISSING, AUTH_USER_INVALID_ACCESS_TOKEN, QUERY_DATA_NO_FOUND, SYSTEM_OR_UNKNOWN_ERROR, DATA_UPDATE_ERROR_NO_FOUND, DATA_SAVE_ERROR, AUTH_USER_TOO_MANY_ERRORS, DATA_REMOVE_ERROR, AUTH_USER_PASSWORD_ERROR, AUTH_USER_NO_FOUND, AUTH_USER_INVALID_ORG, AUTH_ORG_NO_FOUND, EMAIL_ALREADY_EXISTS, ORG_PATH_ALREADY_EXISTS}|*}
 */
const errorCode = require('../errorCode');
const constant = require('../constant');

module.exports = options => {
  return async function(ctx, next) {
    const { userInfo } = ctx.state;
    if (options && options.adminOrg) {
      // 需要管理员的组织才能进行的操作
      if (userInfo.org.type !== 0) {
        ctx.body = errorCode.AUTH_NO_PERMISSION;
        return;
      }
    }
    await next();
  };
};
