'use strict';

/**
 * 人脸信息的离散值设置
 * @param app
 * @returns {Model<Document> | Model<T>}
 */
module.exports = app => {
  const mongoose = app.mongoose;
  const Schema = mongoose.Schema;
  const ProfileSchema = new Schema({
    name: { type: String }, // 自定义的属性显示名称
    key: { type: String }, // 属性取值的key
    required: { type: Boolean, default: false }, // 是否必填字段
    isUnique: { type: Boolean, default: false }, // 是否唯一字段
    componentInfo: {}, // { type: 1输入框， 2 选择框 , data:[ { text, value }]}
    reportQuery: { type: Boolean, default: false }, // 是否提供给报表字段查询
    readOnly: { type: Boolean, default: false }, // 有值时候它只读
    org: { type: Schema.Types.ObjectId, ref: 'Organization' }, // 所属组织,
    createAt: { type: Date, default: Date.now },
    updateAt: { type: Date, default: Date.now },
  });
  return mongoose.model('ProfileSet', ProfileSchema);
};
