'use strict';

/**
 * 设备管理
 * @param app
 * @returns {Model<Document> | Model<T>}
 */
module.exports = app => {
  const mongoose = app.mongoose;
  const Schema = mongoose.Schema;
  const DeviceSchema = new Schema({
    name: { type: String }, // 设备名称
    deviceUuid: { type: String }, // 设备送来的设备标识码
    ip: { type: String }, // 设备的ip地址
    deviceVersion: { type: String }, // 设备软件的版本号
    org: { type: Schema.Types.ObjectId, ref: 'Organization' }, // 设备所属组织,
    deviceType: { type: Number, default: 1 }, // 设备类型 1 门禁机 2 EAIS 3 海康设备 4 扩展其他设备
    enclosure: {}, // 附件信息，例如摄像头等
    createAt: { type: Date, default: Date.now },
    updateAt: { type: Date, default: Date.now }, // 更改时间
    heartbeatAt: { type: Date, default: Date.now },
    verify: { type: Number, default: 0 }, // 授权状态， 0 待审核， 1 审核通过， -1 审核不通过
    verifyInfo: {}, // 审核信息 { at: Date, auditor: { _id, userName } }
    networkState: { type: Number, default: 0 }, // 状态 ，0 离线 1 在线
    state: { type: Number, default: 1 }, // 状态 ，0 删除 1 有效
  });
  return mongoose.model('Device', DeviceSchema);
};
