'use strict';

module.exports = app => {
  const mongoose = app.mongoose;
  const Schema = mongoose.Schema;
  const UserSchema = new Schema({
    userName: { type: String, lowercase: true }, // 除了初始管理员admin 。其他都用email
    password: { type: String },
    passwordVersion: { type: Number, default: 0 }, // 密码版本
    type: { type: Number, default: 1 }, // 用户类型，1 是普通用户，0 管理员
    createAt: { type: Date, default: Date.now },
    state: { type: Number, default: 1 }, // 用户状态 ， 1 正常，0 冻结, -1 删除
    authAt: { type: Date }, // 用户最近的登录时间
    authErrorCount: { type: Number, default: 0 }, // 输错密码次数
    authErrorAt: { type: Date }, // 输错密码的时间
    org: { type: Schema.Types.ObjectId, ref: 'Organization' }, // 用户所属组织
    profile: {
      nickName: { type: String },
      mobile: { type: String },
      email: { type: String },
    },
  });
  return mongoose.model('Sysuser', UserSchema);
};
