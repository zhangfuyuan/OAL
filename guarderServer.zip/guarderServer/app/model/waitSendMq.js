'use strict';

/**
 * 等待推送的消息队列
 * @param app
 * @returns {Model<Document> | Model<T>}
 */
module.exports = app => {
  const mongoose = app.mongoose;
  const Schema = mongoose.Schema;
  const WaitSendMqSchema = new Schema({
    key: { type: String }, // 要触发的消息key
    uuid: { type: String }, // 消息的uuid
    receiverId: { type: String }, // 接收者id
    receiverType: { type: String, default: 'user' }, // 接收者类型。 人， 设备， 其他服务
    data: {}, // 要发送的数据
    org: { type: Schema.Types.ObjectId }, // 所属组织,
    createAt: { type: Date, default: Date.now },
    lastSendAt: { type: Date, default: Date.now },
    sendCount: { type: Number, default: 1 },
  });
  return mongoose.model('WaitSendMq', WaitSendMqSchema);
};
