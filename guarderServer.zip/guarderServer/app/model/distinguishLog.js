'use strict';

/**
 * 人脸识别记录
 * @param app
 * @returns {Model<Document> | Model<T>}
 */
module.exports = app => {
  const mongoose = app.mongoose;
  const Schema = mongoose.Schema;
  const DistinguishLogSchema = new Schema({
    faceId: { type: String }, // 识别到的最佳匹配
    profile: {},
    extendInfo: {}, // 上传的其他扩展信息
    deviceId: { type: String }, // 是哪个抓拍机抓拍到的
    score: { type: String }, // 识别的得分
    img: {}, // weedFs信息
    accessType: { type: Number }, // 出入类型 1 进， 2出
    org: { type: Schema.Types.ObjectId, ref: 'Organization' }, // 所属组织,
    createAt: { type: Date, default: Date.now }, // 服务器这条数据的创建时间
    deviceTime: { type: Date }, // 设备识别的时间
    deviceDate: { type: Date }, // 设备识别的日期，用来做快速分组
  });
  return mongoose.model('DistinguishLog', DistinguishLogSchema);
};
