'use strict';

/**
 * 人脸图片压缩包
 * @param app
 * @returns {Model<Document> | Model<T>}
 */
module.exports = app => {
  const mongoose = app.mongoose;
  const Schema = mongoose.Schema;
  const FaceSchema = new Schema({
    name: { type: String }, // 图片的逻辑名称
    fileName: { type: String }, // 图片的物理名称，通常是个uuid
    feature: {}, // 特征值 { 512plus: Buffer }
    featureErrorCode: {}, // 对此图片提取特征值的结果错误码
    creator: { type: Schema.Types.ObjectId, ref: 'SysUser' }, // 数据创建者
    org: { type: Schema.Types.ObjectId, ref: 'Organization' }, // 人脸所属组织,
    createAt: { type: Date, default: Date.now },
    updateAt: { type: Date, default: Date.now },
    state: { type: Number, default: 1 }, // 状态 ，0 未处理 1 正常，-1 处理失败
    package: {},
  });
  return mongoose.model('FacePackage', FaceSchema);
};
