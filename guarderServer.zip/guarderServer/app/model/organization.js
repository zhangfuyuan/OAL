'use strict';

/**
 * 组织
 * @param app
 * @returns {Model<Document> | Model<T>}
 */
module.exports = app => {
  const mongoose = app.mongoose;
  const Schema = mongoose.Schema;
  const OrgSchema = new Schema({
    name: { type: String }, // 组织的名称，通常是上一级帮他定义的
    saasName: { type: String }, // SAAS 服务要显示的名称，代理商自定义
    path: { type: String, index: true, unique: true }, // 组织自己的路径
    logo: { type: String, index: true }, // 预留，每个组织可以上传自己的logo
    type: { type: Number, default: 1 }, // 类型，1 是普通组织，0 是代理商
    createAt: { type: Date, default: Date.now },
    updateAt: { type: Date, default: Date.now },
    state: { type: Number, default: 1 }, // 状态 ， 1 正常，0 失效
  });
  return mongoose.model('Organization', OrgSchema);
};
