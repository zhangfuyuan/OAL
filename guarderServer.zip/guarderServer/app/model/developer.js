'use strict';

/**
 * 开发者
 */
module.exports = app => {
  const mongoose = app.mongoose;
  const Schema = mongoose.Schema;
  const DeveloperSchema = new Schema({
    key: { type: String, index: true }, // 用户名
    secret: { type: String, index: true }, // 秘钥
    secretVersion: { type: Number, default: 1 },
    authAt: { type: Date }, // 最后一次认证时间
    org: { type: Schema.Types.ObjectId, ref: 'Organization' }, // 所属组织,
    createAt: { type: Date, default: Date.now },
    updater: { type: Schema.Types.ObjectId },
  });
  return mongoose.model('Developer', DeveloperSchema);
};
