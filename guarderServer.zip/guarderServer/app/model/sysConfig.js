'use strict';

/**
 * 系统
 * @param app
 * @returns {Model<Document> | Model<T>}
 */
module.exports = app => {
  const mongoose = app.mongoose;
  const Schema = mongoose.Schema;
  const SysConfigSchema = new Schema({
    key: { type: String }, // 所属设置项类型 faceSize 人脸尺寸限制, maxFaceCount 底库数量上限
    value: {}, // 设置的值，如果是 faceSize { max: { w,h }, min:{ w, h}}
    org: { type: Schema.Types.ObjectId, ref: 'Organization' }, // 所属组织,
    createAt: { type: Date, default: Date.now },
    updateAt: { type: Date, default: Date.now },
  });
  return mongoose.model('SysConfig', SysConfigSchema);
};
