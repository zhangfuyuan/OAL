'use strict';

const Controller = require('egg').Controller;
const errorCode = require('../errorCode');
const constant = require('../constant');
const fsPromises = require('fs').promises;
const sysPath = require('path');

class OrgController extends Controller {
  /**
   * 新增一个组织
   * @returns {Promise<void>}
   */
  async add() {
    const { orgName, email, mobile, contactName, path } = this.ctx.request.body;
    console.log('To add org:', orgName, email, mobile, contactName, path);
    if (!orgName || !path) {
      // 缺失三个必须的参数
      this.ctx.body = errorCode.DATA_MISSING_PARAMETERS;
      return;
    }
    const org = await this.ctx.service.organization.getByPath(path);
    if (org) {
      // 该path已经被使用
      this.ctx.body = errorCode.ORG_PATH_ALREADY_EXISTS;
      return;
    }
    // 新增org
    const newOrg = await this.ctx.service.organization.add({
      type: 1,
      path,
      name: orgName,
    });
    console.log('new org is:', newOrg);
    const newUser = await this.ctx.service.user.add({
      type: 0,
      userName: constant.DEFAULT_ADMIN_USER.userName,
      password: constant.DEFAULT_ADMIN_USER.password,
      org: newOrg._id,
      profile: {
        nickName: contactName || '管理员',
        email,
        mobile,
      },
    });
    console.log('new user is:', newUser);
    await fsPromises.mkdir(sysPath.join(__dirname, `../public/face/${path}`), { recursive: true });
    this.ctx.body = errorCode.RESPONE(newOrg);
  }

  /**
   * 根据path获取组织信息
   * @returns {Promise<void>}
   */
  async getInfo() {
    console.log('bgein getInfo')
    const { path } = this.ctx.params;
    const org = await this.ctx.service.organization.getByPath(path);
    if (org) {
      const agent = await this.ctx.service.organization.getAgent();
      this.ctx.body = errorCode.RESPONE({ org, agent });
      return;
    }
    this.ctx.body = errorCode.QUERY_DATA_NO_FOUND;
  }

  /**
   * 管理员修改Saas的信息
   * @returns {Promise<void>}
   */
  async editSaasInfo() {
    let { _id, saasName } = this.ctx.request.body;
    console.log('this.ctx.state.user.orgId--', this.ctx.state.user.orgId);
    const { userInfo } = this.ctx.state;
    if (!_id) {
      _id = userInfo.org._id.toString();
    }
    if (this.ctx.state.user.orgId.toString() !== _id || userInfo.type !== 0) {
      console.error('Try to editByOrg,but has no permission,org:', _id, ' user:', userInfo);
      this.ctx.body = errorCode.AUTH_NO_PERMISSION;
      return;
    }
    if (!saasName) {
      this.ctx.body = errorCode.DATA_MISSING_PARAMETERS;
      return;
    }
    const orgBean = await this.ctx.service.organization.getById(_id);
    if (orgBean) {
      if (orgBean.state === 0) {
        this.ctx.body = errorCode.AUTH_USER_INVALID_ORG;
        return;
      }
      orgBean.saasName = saasName;
      orgBean.updateAt = new Date();
      await orgBean.save();
      this.ctx.body = errorCode.RESPONE({ org: orgBean });
    } else {
      this.ctx.body = errorCode.AUTH_ORG_NO_FOUND;
    }
  }

  /**
   * 查询组织列表
   * @returns {Promise<void>}
   */
  async getOrgList() {
    const { name, path, state, current, pageSize } = this.ctx.request.body;
    let query = { type: 1 }; // 只查普通组织
    if (name) {
      // eslint-disable-next-line no-eval
      query.name = eval('/' + name + '/i');
    }
    if (path) {
      // eslint-disable-next-line no-eval
      query.path = eval('/' + path + '/i');
    }
    if (state) {
      query.state = state;
    }
    const queryResult = await this.ctx.service.organization.query(query, { current, pageSize });
    // console.log('getOrgList queryResult:', queryResult);
    this.ctx.body = errorCode.RESPONE(queryResult);
  }

  async update() {
    const { orgId, orgName, email, contactName, mobile } = this.ctx.request.body;
    if (!orgName || !orgId) {
      // 缺失三个必须的参数
      this.ctx.body = errorCode.DATA_MISSING_PARAMETERS;
      return;
    }
    let orgBean = await this.ctx.service.organization.getById(orgId);
    if (orgBean) {
      if (orgBean.state === 0) {
        this.ctx.body = errorCode.AUTH_USER_INVALID_ORG;
        return;
      }
      orgBean.name = orgName;
      orgBean.updateAt = new Date();
      await orgBean.save();
      const orgUser = await this.ctx.service.user.queryOne({ org: orgBean._id, type: 0 });
      console.log('orgUser----', orgUser);
      orgUser.profile || (orgUser.profile = {});
      orgUser.profile.nickName = contactName;
      orgUser.profile.email = email;
      orgUser.profile.mobile = mobile;
      orgUser.save();
      orgBean = orgBean.toObject();
      orgBean.contact = orgUser.profile;
      this.ctx.body = errorCode.RESPONE({ org: orgBean });
    } else {
      this.ctx.body = errorCode.AUTH_ORG_NO_FOUND;
    }
  }

  /**
   * 设置组织状态 1 有效 0 失效
   */
  async setState() {
    console.log('setState---')
    const { orgId, state } = this.ctx.params;
    const orgBean = await this.ctx.service.organization.getById(orgId);
    if (orgBean) {
      orgBean.state = state;
      orgBean.updateAt = new Date();
      await orgBean.save();
      this.ctx.body = errorCode.RESPONE({ org: orgBean });
    } else {
      this.ctx.body = errorCode.AUTH_ORG_NO_FOUND;
    }
  }
}
module.exports = OrgController;
