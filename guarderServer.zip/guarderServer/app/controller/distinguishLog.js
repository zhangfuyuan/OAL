'use strict';

const Controller = require('egg').Controller;
const moment = require('moment');
const errorCode = require('../errorCode');
const socketMessageConstant = require('../socketMessageConstant');
// const _ = require('lodash');
// const constant = require('../constant');

class DistinguishLogController extends Controller {
/**
 * 同步识别结果
 */
  async syncAccess() {
    const { data } = this.ctx.request.body;
    if (!data || data.length === 0) {
      this.ctx.body = errorCode.DATA_MISSING_PARAMETERS;
      return;
    }
    // data = JSON.parse(data);
    for (let i = 0; i < data.length; i++) {
      const dl = {
        deviceTime: new Date(data[i].time),
        // img: data[i].img,
        org: this.ctx.state.userInfo.org._id,
        deviceId: this.ctx.state.userInfo._id,
      };

      if (data[i].img) {
        const buf = Buffer.from(data[i].img, 'base64');
        // console.log('buf---', typeof buf);
        const weedFs = await this.ctx.service.seaweed.write(buf);
        // console.log('weedFs----', weedFs);
        if (weedFs && weedFs.fid) {
          dl.img = weedFs;
        }
      }

      let logTime;
      if (data[i].time) {
        logTime = new Date(data[i].time);
      } else {
        logTime = new Date();
      }
      dl.deviceTime = logTime;
      dl.deviceDate = moment(logTime).format('YYYY-MM-DD');
      if (data[i].data) {
        dl.faceId = data[i].data._id;
        dl.score = data[i].data.score;
        dl.accessType = data[i].data.type;
        dl.profile = data[i].data.profile || {};
        dl.profile.name = data[i].data.name;
        dl.extendInfo = data[i].data.extendInfo;
      }
      if (dl.profile) {
        for (const p in dl.profile) {
          dl.profile[p] = dl.profile[p] + '';
        }
      }
      await this.ctx.service.distinguishLog.add(dl);
      this.ctx.service.sendMsg.sendToDeveloper('MESSAGE', socketMessageConstant.DISTINGUISH_LOG(dl), this.ctx.state.userInfo.org._id, true);
      // console.log('ndl==', ndl);
    }
    this.ctx.body = errorCode.RESPONE(data.length, 'sync sucess');
  }

  async fetch() {
    const { begin, end, deviceRegion, faceName, current = 1, pageSize = 20, forExport } = this.ctx.request.body;
    const deviceList = deviceRegion;
    let { profileQuery } = this.ctx.request.body;
    console.log('fetch ---- ', profileQuery);
    if (faceName) {
      if (!profileQuery) {
        profileQuery = {};
      }
      profileQuery.name = faceName;
    }
    if (!begin || !end) {
      this.ctx.body = errorCode.DATA_MISSING_PARAMETERS;
      return;
    }
    // console.log('profileQuery -- ', profileQuery, begin, end);
    let page = { current, pageSize };
    if (forExport) {
      page = false;
    }
    // console.log('begin----', begin);
    const logList = await this.ctx.service.distinguishLog.getAllByDateRanges(new Date(begin + ' 00:00:00'), new Date(end + ' 23:59:59'), this.ctx.state.userInfo.org._id, page, deviceList, profileQuery);
    // console.log('fetch logList---', logList);
    this.ctx.body = errorCode.RESPONE(logList);
  }

  async fetchByFace() {
    const { faceId, date } = this.ctx.params;
    let resultList = await this.ctx.service.distinguishLog.query({
      org: this.ctx.state.userInfo.org._id,
      faceId,
      deviceTime: {
        $gt: moment(`${date} 00:00:00`).toDate(),
        $lte: moment(`${date} 23:59:59`).toDate(),
      },
    });
    resultList = resultList.map(item => {
      item = item.toObject();
      if (item.img && item.img.url) {
        const tempArray = item.img.url.split(':');
        item.img = `/faceImg/${tempArray[1]}/${item.img.fid}`;
      }
      return item;
    });
    this.ctx.body = errorCode.RESPONE(resultList);
  }
}
module.exports = DistinguishLogController;
