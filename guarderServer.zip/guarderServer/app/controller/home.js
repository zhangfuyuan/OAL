'use strict';

const Controller = require('egg').Controller;
const packages = require('../../package');

class HomeController extends Controller {
  async index() {
    const { ctx } = this;
    await ctx.render('index.html');
  }
  async sysInfo() {
    const { ctx } = this;
    ctx.body = {
      res: 1,
      data: {
        version: packages.version,
        createAt: packages.createAt,
        description: packages.description,
      },
    };
  }
}

module.exports = HomeController;
