'use strict';

const uuid = require('uuid');
const Controller = require('egg').Controller;
const errorCode = require('../errorCode');
const socketMessageConstant = require('../socketMessageConstant');
const constant = require('../constant');

class DeviceController extends Controller {
    /**
     * 设备主动注册接口
     */
  async register() {
    const { deviceUuid, deviceName, orgPath, deviceType, enclosure } = this.ctx.request.body;
    // enclosure 附件信息，例如摄像头列表
    if (!orgPath || !deviceUuid || !deviceType) {
    // 缺失三个必须的参数
      this.ctx.body = errorCode.DATA_MISSING_PARAMETERS;
      return;
    }
    console.log('orgPath---', orgPath);
    const orgInfo = await this.ctx.service.organization.getByPath(orgPath);
    console.log('orgInfo---', orgInfo);
    if (!orgInfo || orgInfo.state === 0) {
    // 所选组织不存在
      this.ctx.body = errorCode.AUTH_ORG_NO_FOUND;
      return;
    }
    const deviceInfo = await this.ctx.service.device.getByUuidAndOrg({ deviceUuid, org: orgInfo._id });
    if (deviceInfo && deviceInfo.state !== 0) {
      // 重复注册
      const token = this.app.jwt.sign({ _id: deviceInfo._id.toString(), orgInfo: orgInfo._id, type: 'device' }, this.config.jwt.secret, {
        expiresIn: constant.AUTH_TOKEN_DEVICE_EXPIRES_TIME,
      });

      const registerResault = errorCode.DEVICE_ALREADY_EXISTS;
      registerResault.token = token;
      this.ctx.body = registerResault;
      // this.ctx.body = errorCode.RESPONE(token, 'Apply register success');
      return;
    }
    if (deviceInfo && deviceInfo.state === 0) {
      // 属于被删除的设备，重新申请注册
      deviceInfo.state = 1;
      deviceInfo.verify = 0;
      deviceInfo.name = deviceName;
      deviceInfo.verifyInfo = {};
      deviceInfo.save();
      const token = this.app.jwt.sign({ _id: deviceInfo._id.toString(), orgInfo: orgInfo._id, type: 'device' }, this.config.jwt.secret, {
        expiresIn: constant.AUTH_TOKEN_DEVICE_EXPIRES_TIME,
      });
      console.log('device token is:', token);
      this.ctx.service.sendMsg.sendToDeveloper('MESSAGE', socketMessageConstant.DEVICE_REGISTER(deviceInfo), deviceInfo.org._id, false);
      this.ctx.body = errorCode.RESPONE(token, 'Apply register success. Please wait for approval');
      return;
    }
    const deviceVersion = this.ctx.get('device-version');
    const clientIp = this.ctx.ip;
    console.log('deviceVersion----', deviceVersion);
    const newDevice = await this.ctx.service.device.add({
      name: deviceName,
      deviceUuid,
      ip: clientIp,
      deviceVersion,
      org: orgInfo._id,
      deviceType,
    });
    console.log('new device is :', newDevice);
    const token = this.app.jwt.sign({ _id: newDevice._id.toString(), orgInfo: orgInfo._id, type: 'device' }, this.config.jwt.secret, {
      expiresIn: constant.AUTH_TOKEN_DEVICE_EXPIRES_TIME,
    });
    console.log('device token is:', token);
    this.ctx.service.sendMsg.sendToDeveloper('MESSAGE', socketMessageConstant.DEVICE_REGISTER(newDevice), orgInfo._id, false);
    this.ctx.body = errorCode.RESPONE(token, 'Apply register success. Please wait for approval');
  }

  /**
   * 获取设备列表
   * verify 授权状态  0 待审核， 1 审核通过， -1 审核不通过
   */
  async getDeviceList() {
    const { verify } = this.ctx.params;
    const deviceList = await this.ctx.service.device.queryNoPage({ org: this.ctx.state.userInfo.org._id, verify, state: 1 });
    this.ctx.body = errorCode.RESPONE(deviceList);
  }

  /**
   * 设备审核
   * result 审核结果 1通过 -1不通过
   */
  async deviceVerify() {
    const { result } = this.ctx.params;
    this.ctx.state.deviceInfo.verify = result;
    this.ctx.state.deviceInfo.verifyInfo = {
      at: new Date(),
      auditor: {
        _id: this.ctx.state.userInfo._id,
        userName: this.ctx.state.userInfo.userName,
      },
    };
    this.ctx.state.deviceInfo.save();
    if (result == 1) {
      // 审核通过，需要推送人脸库到设备，逻辑待确定
      this.ctx.service.sendMsg.sendToDeviceById('MESSAGE', this.ctx.state.deviceInfo._id, this.ctx.state.userInfo.org, 100);
      this.ctx.service.sendMsg.sendToDeveloper('MESSAGE', socketMessageConstant.DEVICE_VERIFIED(this.ctx.state.deviceInfo), this.ctx.state.userInfo.org._id, true);
      this.ctx.service.sendMsg.sendMsgToDevice('MESSAGE', this.ctx.state.deviceInfo._id, this.ctx.state.userInfo.org, socketMessageConstant.DEVICE_VERIFIED());
    } else {
      this.ctx.service.sendMsg.sendToDeveloper('MESSAGE', socketMessageConstant.DEVICE_APPROVED(this.ctx.state.deviceInfo), this.ctx.state.userInfo.org._id, true);
      this.ctx.service.sendMsg.sendMsgToDevice('MESSAGE', this.ctx.state.deviceInfo._id, this.ctx.state.userInfo.org, socketMessageConstant.DEVICE_APPROVED());
    }
    this.ctx.body = errorCode.RESPONE(this.ctx.state.deviceInfo);
  }
  async reomve() {
    this.ctx.state.deviceInfo.state = 0;
    this.ctx.state.deviceInfo.save();
    this.ctx.service.waitSendMq.remove({ org: this.ctx.state.userInfo.org._id, receiverType: 'device', receiverId: this.ctx.state.deviceInfo._id.toString() });
    // if (msgMqList) {
    //   for (let i = 0; i < msgMqList.length; i++) {
    //     msgMqList[i].reomve();
    //   }
    // }
    /**
     * 断开Socket连接
     */
    const socketClient = await this.ctx.service.sendMsg.getScoketClientById(this.ctx.state.deviceInfo._id);
    // console.log('--socketClient-----', socketClient);
    if (socketClient && socketClient.length > 0) {
      // const { socket } = this.ctx;
      for (let p = 0; p < socketClient.length; p++) {
        // 立即推送踢出的事件,插队
        socketClient[p].emit('MESSAGE', { uuid: uuid.v1(), data: socketMessageConstant.DEVICE_KICK_OFF(), createAt: new Date() });
        socketClient[p].disconnect(true);
      }
    }
    // 推送通知给开发者
    this.ctx.service.sendMsg.sendToDeveloper('MESSAGE', socketMessageConstant.DEVICE_REMOVE(
      { device: this.ctx.state.deviceInfo, at: new Date() }), this.ctx.state.userInfo.org._id, true);
    this.ctx.body = errorCode.RESPONE(this.ctx.state.deviceInfo);
  }
  async setName() {
    const { name } = this.ctx.params;
    this.ctx.state.deviceInfo.name = name;
    this.ctx.state.deviceInfo.save();
    // 推送通知给开发者
    this.ctx.service.sendMsg.sendToDeveloper('MESSAGE', socketMessageConstant.DEVICE_RENAME(
      { device: this.ctx.state.deviceInfo, at: new Date() }), this.ctx.state.userInfo.org._id, true);
    this.ctx.body = errorCode.RESPONE(this.ctx.state.deviceInfo);
  }
}

module.exports = DeviceController;
