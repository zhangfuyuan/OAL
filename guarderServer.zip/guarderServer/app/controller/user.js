'use strict';

const Controller = require('egg').Controller;
const moment = require('moment');
const errorCode = require('../errorCode');
const constant = require('../constant');
const _ = require('lodash');

class UserController extends Controller {
  /**
   * 用户名密码登录
   * @returns {Promise<void>}
   */
  async signin() {
    const { userName, password } = this.ctx.request.body;
    let { path } = this.ctx.request.body;
    path || (path = constant.DEFAULT_ORG_PATH);
    const org = await this.ctx.service.organization.getByPath(path);
    // this.logger.log('signin org:', org);
    if (!org) {
      this.ctx.body = errorCode.AUTH_ORG_NO_FOUND;
      return;
    }
    const user = await this.ctx.service.user.getByUserName(userName, org._id);
    if (!user) {
      this.ctx.body = errorCode.AUTH_USER_NO_FOUND;
      return;
    }
    if (user.authErrorCount >= constant.AUTH_MAX_ERROR_COUNT) {
      // 错误次数已经超过上限
      if (moment().isAfter(moment(user.authErrorAt).add(constant.FREEZING_TIME_AFTER_AUTH_ERROR, 'm'))) {
        // 判断当前时间是否在认证错误+冻结时间之后
        user.authErrorCount = 0;
        await user.save();
      } else {
        // 返回错误次数过多的提示
        this.ctx.body = errorCode.AUTH_USER_TOO_MANY_ERRORS;
        return;
      }
    }
    if (user.org.state === 0) {
      // 用户所属组织已经失效
      this.ctx.body = errorCode.AUTH_USER_INVALID_ORG;
      return;
    }
    if (password !== user.password) {
      // 密码错误，需要记录错误次数
      user.authErrorCount = (user.authErrorCount + 1);
      user.authErrorAt = new Date();
      await user.save();
      this.ctx.body = errorCode.AUTH_USER_PASSWORD_ERROR;
      return;
    }
    // 登录成功
    user.authErrorCount = 0;
    user.authAt = new Date();
    user.save();
    const token = this.app.jwt.sign({ _id: user._id.toString(), orgId: org._id, passwordVersion: user.passwordVersion }, this.config.jwt.secret, {
      expiresIn: constant.AUTH_TOKEN_EXPIRES_TIME,
    });
    const agent = await this.ctx.service.organization.getAgent();
    const { MENUS } = constant;
    let userMeuns = [];
    if (user.org.type === 0) {
      // 管理员组织
      userMeuns = MENUS;
    } else {
      userMeuns = _.filter(MENUS, item => !item.scope);
    }
    this.ctx.body = errorCode.RESPONE({ user, token, agent, menus: userMeuns });
  }

  /**
   * 交换token，重新获取用户信息
   * @returns {Promise<void>}
   */
  async authByToken() {
    // this.ctx.body = this.ctx.state.user;
    const token = this.app.jwt.sign({ _id: this.ctx.state.userInfo._id.toString(), orgId: this.ctx.state.userInfo.org._id }, this.config.jwt.secret, {
      expiresIn: constant.AUTH_TOKEN_EXPIRES_TIME,
    });
    const agent = await this.ctx.service.organization.getAgent();
    const { MENUS } = constant;
    let userMeuns = [];
    if (this.ctx.state.userInfo.org.type === 0) {
      // 管理员组织
      userMeuns = MENUS;
    } else {
      userMeuns = _.filter(MENUS, item => !item.scope);
    }
    this.ctx.body = errorCode.RESPONE({ user: this.ctx.state.userInfo, token, agent, menus: userMeuns });
  }

  async modifyPsw() {
    const { oldpassword, newpassword } = this.ctx.request.body;
    console.log('modifyPsw----->', oldpassword, newpassword, this.ctx.state.userInfo.password);
    console.log('modifyUser:', this.ctx.state.userInfo);
    if (!newpassword) {
      this.ctx.body = errorCode.DATA_MISSING_PARAMETERS;
      return;
    }
    if (oldpassword) {
      // 传了旧密码，就校验旧密码
      if (oldpassword !== this.ctx.state.userInfo.password) {
        this.ctx.body = errorCode.AUTH_USER_PASSWORD_ERROR;
        return;
      }
    }
    if (newpassword) {
      if (newpassword === this.ctx.state.userInfo.password) {
        this.ctx.body = errorCode.AUTH_USER_NEW_PASSWORD_ERROR;
        return;
      }
    }
    this.ctx.state.userInfo.password = newpassword;
    this.ctx.state.userInfo.passwordVersion = (this.ctx.state.userInfo.passwordVersion + 1);
    await this.ctx.state.userInfo.save();
    this.ctx.body = errorCode.RESPONE({ passwordVersion: this.ctx.state.userInfo.passwordVersion });
  }

  /**
   * 新增用户
   */
  async add() {
    const { userName, nickName, mobile, email } = this.ctx.request.body;
    if (!userName) {
      // 缺失必须的参数
      this.ctx.body = errorCode.DATA_MISSING_PARAMETERS;
      return;
    }
    const hasUser = await this.ctx.service.user.getBaseInfoByUserName(userName, this.ctx.state.userInfo.org._id);
    if (hasUser) {
      // 已经存在
      this.ctx.body = errorCode.AUTH_USERNAME_EXIST;
      return;
    }
    const newUser = await this.ctx.service.user.add({
      userName,
      password: constant.DEFAULT_USER_PASSWORD,
      org: this.ctx.state.userInfo.org._id,
      profile: {
        nickName,
        email,
        mobile,
      },
    });
    console.log('new user is:', newUser);
    this.ctx.body = errorCode.RESPONE(newUser);
  }

  /**
   * 修改用户信息
   */
  async update() {
    const { nickName, mobile, email } = this.ctx.request.body;
    const { userInfo } = this.ctx.state;
    userInfo.profile || (userInfo.profile = {});
    userInfo.profile.nickName = nickName;
    userInfo.profile.mobile = mobile;
    userInfo.profile.email = email;
    userInfo.save();
    this.ctx.body = errorCode.RESPONE(userInfo);
  }

  /**
   * 查询组织内的用户列表
   * @returns {Promise<void>}
   */
  async getUserList() {
    const { userName, state, current, pageSize } = this.ctx.request.body;
    const query = { org: this.ctx.state.userInfo.org._id }; // 只查本组织的
    if (userName) {
      // eslint-disable-next-line no-eval
      query.userName = userName;
    }
    if (state) {
      // eslint-disable-next-line no-eval
      query.state = state;
    } else {
      query.state = 1;
    }
    const queryResult = await this.ctx.service.user.query(query, { current, pageSize });
    console.log('getUserList queryResult:', queryResult);
    this.ctx.body = errorCode.RESPONE(queryResult);
  }

  /**
   * 对用户账户进行操作
   */
  async handleOperation() {
    const { userId, action } = this.ctx.params;
    const query = { org: this.ctx.state.userInfo.org._id, _id: userId }; // 只查本组织的
    const userInfo = await this.ctx.service.user.queryOne(query);
    console.log('handleOperation userInfo is:', userInfo);
    if (!userInfo) {
      this.ctx.body = errorCode.DATA_UPDATE_ERROR_NO_FOUND;
      return;
    }
    if (action === 'delete') {
      // 删除用户
      userInfo.state = -1;
      userInfo.save();
    } else if (action === 'resetPsw') {
      userInfo.password = constant.DEFAULT_USER_PASSWORD;
      userInfo.passwordVersion = 0;
      userInfo.save();
    } else {
      this.ctx.body = errorCode.UNKNOWN_OPERATION;
      return;
    }
    this.ctx.body = errorCode.RESPONE(userInfo, 'update success');
  }
}

module.exports = UserController;
