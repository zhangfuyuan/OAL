'use strict';

const Controller = require('egg').Controller;
const errorCode = require('../errorCode');
const constant = require('../constant');
const uuidv1 = require('uuid/v1');

class DeveloperController extends Controller {
  async add() {
    const oldInfo = await this.ctx.service.developer.queryOne({ org: this.ctx.state.userInfo.org._id });
    if (oldInfo) {
      // 已经存在，直接返回存在的
      this.ctx.body = errorCode.RESPONE(oldInfo);
      return;
    }
    const deveInfo = {
      key: uuidv1(),
      secret: uuidv1(),
      org: this.ctx.state.userInfo.org._id,
    };
    const developer = await this.ctx.service.developer.add(deveInfo);
    this.ctx.body = errorCode.RESPONE(developer);
  }

  async resetSecret() {
    const oldInfo = await this.ctx.service.developer.queryOne({ org: this.ctx.state.userInfo.org._id });
    if (oldInfo) {
      // 已经存在，直接修改和返回存在的
      oldInfo.secret = uuidv1();
      oldInfo.secretVersion = oldInfo.secretVersion + 1;
      oldInfo.save();
      this.ctx.body = errorCode.RESPONE(oldInfo);
      return;
    }
    // 不存在就新增
    const deveInfo = {
      key: uuidv1(),
      secret: uuidv1(),
      org: this.ctx.state.userInfo.org._id,
    };
    const developer = await this.ctx.service.developer.add(deveInfo);
    this.ctx.body = errorCode.RESPONE(developer);
  }

  /**
   * 获取开发者的信息
   */
  async getDevInfo() {
    const oldInfo = await this.ctx.service.developer.queryOne({ org: this.ctx.state.userInfo.org._id });
    this.ctx.body = errorCode.RESPONE(oldInfo);
  }

  /**
   * 平台认证
   */
  async platformAuth() {
    const { key, secret } = this.ctx.request.body;
    if (!key || !secret) {
      this.ctx.body = errorCode.DATA_MISSING_PARAMETERS;
      return;
    }
    const deveInfo = await this.ctx.service.developer.queryOne({ key, secret });
    if (deveInfo) {
      deveInfo.authAt = new Date();
      const token = this.app.jwt.sign({ _id: deveInfo._id.toString(), orgId: deveInfo.org._id, secretVersion: deveInfo.secretVersion, type: 'platform' }, this.config.jwt.secret, {
        expiresIn: constant.AUTH_TOKEN_EXPIRES_TIME,
      });
      this.ctx.body = errorCode.RESPONE({ token });
      return;
    }
    this.ctx.body = errorCode.QUERY_DATA_NO_FOUND;
  }
/**
 * 平台刷新token
 */
  async refresh() {
    const { userInfo } = this.ctx.state;
    userInfo.authAt = new Date();
    const token = this.app.jwt.sign({ _id: userInfo._id.toString(), orgId: userInfo.org._id, secretVersion: userInfo.secretVersion, type: 'platform' }, this.config.jwt.secret, {
      expiresIn: constant.AUTH_TOKEN_EXPIRES_TIME,
    });
    this.ctx.body = errorCode.RESPONE({ token });
  }
}
module.exports = DeveloperController;
