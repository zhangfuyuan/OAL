'use strict';

const Controller = require('egg').Controller;
const errorCode = require('../errorCode');
const constant = require('../constant');

class SysConfigController extends Controller {
  async setConfig() {
    const { data } = this.ctx.request.body;
    if (!data) {
      // 数据缺失
      this.ctx.body = errorCode.DATA_MISSING_PARAMETERS;
      return;
    }
    for (let i = 0; i < data.length; i++) {
      const configBean = await this.ctx.service.sysConfig.queryOne({ org: this.ctx.state.user.orgId, key: data[i].key });
      if (configBean) {
        configBean.value = data[i].value;
        configBean.save();
      } else {
        const toAdd = {
          key: data[i].key,
          value: data[i].value,
          org: this.ctx.state.user.orgId,
        };
        await this.ctx.service.sysConfig.add(toAdd);
      }
    }
    const resultList = await this.ctx.service.sysConfig.queryByOrg(this.ctx.state.user.orgId);
    this.ctx.body = errorCode.RESPONE(resultList);
  }
  /**
 * 获取配置
 */
  async getConfig() {
    const resultList = await this.ctx.service.sysConfig.queryByOrg(this.ctx.state.user.orgId);
    this.ctx.body = errorCode.RESPONE(resultList);
  }
}
module.exports = SysConfigController;
