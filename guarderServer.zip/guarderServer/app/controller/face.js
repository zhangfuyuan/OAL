'use strict';

const Controller = require('egg').Controller;
const path = require('path');
const toArray = require('stream-to-array');
const sendToWormhole = require('stream-wormhole');
const fsPromises = require('fs').promises;
const uuidv1 = require('uuid/v1');
const errorCode = require('../errorCode');
const socketMessageConstant = require('../socketMessageConstant');

class FaceController extends Controller {
  async upload() {
    const stream = await this.ctx.getFileStream();
    let buf;
    try {
      const parts = await toArray(stream);
      buf = Buffer.concat(parts);
    } catch (err) {
      await sendToWormhole(stream);
      throw err;
    }
    const { userInfo } = this.ctx.state;
    // const fileName = uuidv1() + path.extname(stream.filename).toLowerCase();
    const tempName = stream.filename.split('.');
    tempName.pop();
    const orgName = tempName.join('.');
    if (!orgName.startsWith('0_')) {
      this.ctx.body = errorCode.IMAGE_NAME_IS_NOT_STANDARD;
      return;
    }
    // const target = path.join(__dirname, `../public/face/${userInfo.org.path}`, fileName);
    const profiles = await this.ctx.service.profileSet.queryByOrg(this.ctx.state.userInfo.org._id);
    const faceData = {
      name: orgName,
      // fileName,
      creator: userInfo._id,
      org: userInfo.org._id,
      from: { type: 'device' },
    };
    const profileValueList = [];
    if (orgName) {
      const infos = orgName.split('_');
      if (infos.length > 2) {
        faceData.name = infos[1];
        faceData.profile = {};
        for (let i = 2; i < infos.length; i++) {
          if (profiles[i - 2]) {
            faceData.profile[profiles[i - 2].key] = infos[i];
            profileValueList.push(infos[i]);
          }
        }
      }
    }
    // console.log('orgName----', orgName);
    // console.log('faceData.profile----', faceData.profile);
    // 校验扩展属性
    const checkResult = await this.ctx.service.face.checkExtendAttr(userInfo.org._id, profileValueList);
    console.log('checkResult ---->', checkResult);
    if (checkResult.res < 1) {
      this.ctx.body = checkResult;
      return;
    }
    /**
    if (checkResult.errorCode === 5007) {
      // 违反唯一约束
      this.ctx.body = checkResult;
      return;
    } else if (checkResult.errorCode === 5005) {
      // 缺乏必填值
      this.ctx.body = checkResult;
      return;
    } else if (checkResult.errorCode === 4003) {
      // 与配置的下拉框值不匹配
      this.ctx.body = checkResult;
      return;
    }
    **/
    const weedFs = await this.ctx.service.seaweed.write(buf);
    // console.log('weedFs----', weedFs);
    if (!weedFs || !weedFs.fid) {
      this.ctx.body = errorCode.DATA_SAVE_ERROR;
      return;
    }
    // 文件写成功
    faceData.fileInfo = weedFs;
    faceData.fileName = weedFs.fid;
    // await fsPromises.writeFile(target, buf);
    // console.log('faceData----', faceData);
    const urlTempInfo = weedFs.url.split(':');
    const faceBean = await this.ctx.service.face.add(faceData);
    // 向该组织的所有设备发送消息
    const sendObj = faceBean.toObject();
    sendObj.imgPath = `/faceImg/${urlTempInfo[1]}/${sendObj.fileName}`;
    this.ctx.service.sendMsg.sendToDevice('MESSAGE', socketMessageConstant.FACE_ADD(sendObj), userInfo.org._id, true);
    // this.ctx.service.sendMsg.sendToUser('MESSAGE', socketMessageConstant.FACE_ADD(sendObj), userInfo.org._id, true); // 向人发送的逻辑，测试过了就去除
    this.ctx.service.sendMsg.sendToDeveloper('MESSAGE', socketMessageConstant.FACE_ADD(sendObj), userInfo.org._id, true);
    this.ctx.body = errorCode.RESPONE(faceBean);
  }
  /**
   * 获取同组织下的人脸列表
   */
  async fetchList() {
    const { name, featureState, current, pageSize } = this.ctx.request.body;
    const query = { org: this.ctx.state.userInfo.org._id, state: 1 };
    if (featureState !== 'all') {
      query.featureState = featureState;
    }
    if (name) {
      // eslint-disable-next-line no-eval
      query.name = eval('/' + name + '/i');
    }
    // console.log('query:', query)
    const queryResult = await this.ctx.service.face.query(query, { current, pageSize });
    queryResult.list = queryResult.list.map(item => {
      const sendObj = item.toObject();
      if (item.fileInfo && item.fileInfo.url) {
        const urlTempInfo = item.fileInfo.url.split(':');
        sendObj.imgPath = `/faceImg/${urlTempInfo[1]}/${sendObj.fileName}`;
      }
      return sendObj;
    });
    // console.log('getFaceList queryResult:', queryResult);
    this.ctx.body = errorCode.RESPONE(queryResult);
  }

  /**
   * 同步人脸(设备调用) 废弃
   */
  async syncFace() {
    const { page, pageSize } = this.ctx.params;
    const query = { org: this.ctx.state.userInfo.org._id, state: 1 };
    const queryResult = await this.ctx.service.face.query(query, { current: Number(page), pageSize: Number(pageSize) });
    if (queryResult.list) {
      queryResult.list = queryResult.list.map(item => {
        item = item.toObject();
        item.imgPath = `/public/face/${this.ctx.state.userInfo.org.path}/${item.fileName}`;
        return item;
      });
    }
    console.log('syncFace:', queryResult);
    this.ctx.body = errorCode.RESPONE(queryResult);
  }

  /**
   * 重命名
   */
  async rename() {
    const { name, faceId } = this.ctx.params;
    const query = { org: this.ctx.state.userInfo.org._id, _id: faceId };
    const queryResult = await this.ctx.service.face.queryOne(query);
    if (queryResult) {
      queryResult.name = name;
      queryResult.save();
      this.ctx.body = errorCode.RESPONE(queryResult, 'Update Success');
      return;
    }
    this.ctx.body = errorCode.QUERY_DATA_NO_FOUND;
  }
  async modify() {
    const { faceId } = this.ctx.params;
    const { name, profile } = this.ctx.request.body;
    console.log('faceId, name, profile:', faceId, name, profile);
    const query = { org: this.ctx.state.userInfo.org._id, _id: faceId };
    const queryResult = await this.ctx.service.face.queryOne(query);
    const profileValueArray = [];
    const attrSettingList = await this.ctx.service.profileSet.queryByOrg(this.ctx.state.userInfo.org._id);
    if (profile) {
      for (let i = 0; i < attrSettingList.length; i++) {
        profileValueArray.push(profile[attrSettingList[i].key]);
      }
    }

    if (queryResult) {
      const checkResult = await this.ctx.service.face.checkExtendAttr(this.ctx.state.userInfo.org._id, profileValueArray, faceId);
      console.log('checkResult------', checkResult);
      if (checkResult.res < 0) {
        this.ctx.body = checkResult;
        return;
      }

      queryResult.name = name;
      queryResult.profile = profile;
      queryResult.save();
      // 向该组织的所有设备发送消息
      const sendObj = queryResult.toObject();
      const urlTempInfo = sendObj.fileInfo.url.split(':');
      sendObj.imgPath = `/faceImg/${urlTempInfo[1]}/${sendObj.fileName}`;
      this.ctx.service.sendMsg.sendToDevice('MESSAGE', socketMessageConstant.FACE_MODIFY_PROFILE(sendObj), this.ctx.state.userInfo.org._id, true);
      // this.ctx.service.sendMsg.sendToUser('MESSAGE', socketMessageConstant.FACE_MODIFY_PROFILE(sendObj), this.ctx.state.userInfo.org._id, false);
      this.ctx.service.sendMsg.sendToDeveloper('MESSAGE', socketMessageConstant.FACE_MODIFY_PROFILE(sendObj), this.ctx.state.userInfo.org._id, true);
      this.ctx.body = errorCode.RESPONE(queryResult, 'Update Success');
      return;
    }
    this.ctx.body = errorCode.QUERY_DATA_NO_FOUND;
  }

  async remove() {
    const { faceId } = this.ctx.params;
    const query = { org: this.ctx.state.userInfo.org._id, _id: faceId };
    const queryResult = await this.ctx.service.face.queryOne(query);
    if (queryResult) {
      queryResult.state = 0;
      queryResult.save();
      this.ctx.service.sendMsg.sendToDevice('MESSAGE', socketMessageConstant.FACE_REMOVE(queryResult), this.ctx.state.userInfo.org._id, true);
      // this.ctx.service.sendMsg.sendToUser('MESSAGE', socketMessageConstant.FACE_REMOVE(queryResult), this.ctx.state.userInfo.org._id, false);
      this.ctx.service.sendMsg.sendToDeveloper('MESSAGE', socketMessageConstant.FACE_MODIFY_PROFILE(queryResult), this.ctx.state.userInfo.org._id, true);
      this.ctx.body = errorCode.RESPONE(queryResult, 'Delete Success');
      return;
    }
    this.ctx.body = errorCode.QUERY_DATA_NO_FOUND;
  }

  async removeAll() {
    const removeCount = await this.ctx.service.face.removeAll(this.ctx.state.userInfo.org._id);
    console.log('removeCount----', removeCount);
    this.ctx.body = errorCode.RESPONE(removeCount, 'Delete Success');
  }

  /**
   * 修改人脸图片
   */
  async updateImg() {
    const { faceId } = this.ctx.params;
    const query = { org: this.ctx.state.userInfo.org._id, _id: faceId };
    const queryResult = await this.ctx.service.face.queryOne(query);
    if (!queryResult) {
      this.ctx.body = errorCode.QUERY_DATA_NO_FOUND;
      return;
    }
    const stream = await this.ctx.getFileStream();
    let buf;
    try {
      const parts = await toArray(stream);
      buf = Buffer.concat(parts);
    } catch (err) {
      await sendToWormhole(stream);
      throw err;
    }
    // const { userInfo } = this.ctx.state;
    // const fileName = uuidv1() + path.extname(stream.filename).toLowerCase();
    // const target = path.join(__dirname, `../public/face/${userInfo.org.path}`, fileName);

    const weedFs = await this.ctx.service.seaweed.write(buf);
    // console.log('weedFs----', weedFs);
    if (!weedFs || !weedFs.fid) {
      this.ctx.status = 500;
      return;
    }
    // 文件写成功
    queryResult.fileInfo = weedFs;
    queryResult.fileName = weedFs.fid;
    const urlTempInfo = weedFs.url.split(':');
    // await fsPromises.writeFile(target, buf);
    // queryResult.fileName = fileName;
    queryResult.save();
    const sendObj = queryResult.toObject();
    sendObj.imgPath = `/faceImg/${urlTempInfo[1]}/${sendObj.fileName}`;
    this.ctx.service.sendMsg.sendToDevice('MESSAGE', socketMessageConstant.FACE_MODIFY_IMG(sendObj), this.ctx.state.userInfo.org._id, true);
    this.ctx.service.sendMsg.sendToDeveloper('MESSAGE', socketMessageConstant.FACE_MODIFY_IMG(sendObj), this.ctx.state.userInfo.org._id, true);
    // this.ctx.service.sendMsg.sendToUser('MESSAGE', socketMessageConstant.FACE_REMOVE(sendObj), this.ctx.state.userInfo.org._id, false);
    this.ctx.body = errorCode.RESPONE(queryResult, 'Update Success');
  }

  /**
   * 根据特征值识别人脸
   */
  async recognitionFeatures(){
    
  }

  /**
   * 传入图片，识别人脸
   */
  async recognitionImg() {
    const stream = await this.ctx.getFileStream();
    let buf;
    try {
      const parts = await toArray(stream);
      buf = Buffer.concat(parts);
    } catch (err) {
      await sendToWormhole(stream);
      throw err;
    }
  }
  /**
   * 新增个人信息的属性
   */
  async addProfileAttribute() {
    const { name, key, required, isUnique, componentInfo, reportQuery, readOnly } = this.ctx.request.body;
    if (!key || !name) {
      this.ctx.body = errorCode.DATA_MISSING_PARAMETERS;
      return;
    }
    if (key === 'name') {
      this.ctx.body = errorCode.ATTRIBUTE_ALREADY_EXISTS;
      return;
    }
    const queryResult = await this.ctx.service.profileSet.query({ org: this.ctx.state.userInfo.org._id, $or: [{ key }, { name }] });
    console.log('addProfileAttribute queryResult:', queryResult);
    if (queryResult) {
      this.ctx.body = errorCode.ATTRIBUTE_ALREADY_EXISTS;
      return;
    }
    const attributeBean = await this.ctx.service.profileSet.add({ name, key, required, isUnique, componentInfo, reportQuery, readOnly, org: this.ctx.state.userInfo.org._id });
    this.ctx.body = errorCode.RESPONE(attributeBean);
  }
  /**
    * 修改个人属性的信息
  */
  async updateProfileAttribute() {
    const { _id, name, required, isUnique, componentInfo, reportQuery, readOnly } = this.ctx.request.body;
    if (!_id || !name) {
      this.ctx.body = errorCode.DATA_MISSING_PARAMETERS;
      return;
    }
    const queryResult = await this.ctx.service.profileSet.query({ org: this.ctx.state.userInfo.org._id, _id });
    if (queryResult) {
      queryResult.name = name;
      queryResult.required = required;
      queryResult.isUnique = isUnique;
      queryResult.componentInfo = componentInfo;
      queryResult.reportQuery = reportQuery;
      queryResult.readOnly = readOnly;
      queryResult.save();
      this.ctx.body = errorCode.RESPONE(queryResult, 'Update success');
      return;
    }
    this.ctx.body = errorCode.QUERY_DATA_NO_FOUND;
  }
/**
 * 获取属性列表
 */
  async getProfileAttribute() {
    const attributes = await this.ctx.service.profileSet.queryByOrg(this.ctx.state.userInfo.org._id);
    this.ctx.body = errorCode.RESPONE(attributes);
  }

  /**
   * 删除属性值
   */
  async removeProfileAttribute() {
    const { attributeId } = this.ctx.params;
    const queryResult = await this.ctx.service.profileSet.query({ org: this.ctx.state.userInfo.org._id, _id: attributeId });
    if (queryResult) {
      queryResult.remove();
      this.ctx.body = errorCode.RESPONE(queryResult, 'Delete Success');
      return;
    }
    this.ctx.body = errorCode.QUERY_DATA_NO_FOUND;
  }
}
module.exports = FaceController;
