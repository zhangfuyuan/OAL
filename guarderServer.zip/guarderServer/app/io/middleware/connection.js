'use strict';

const jwt = require('jsonwebtoken');
const socketMessageConstant = require('../../socketMessageConstant');

module.exports = app => {
  return async (ctx, next) => {
    const { socket, session } = ctx;
    const query = socket.handshake.query;
    const clientId = socket.id;
    console.log(app.config.jwt, '--connected--', query);
    // 踢出房间
    const kickOut = () => {
      socket.adapter.remoteDisconnect(clientId, true, err => {
        socket.emit('ACK', '登录状态已改变，请重新登陆');
        console.log(`${new Date()}\tKick { ${clientId} } out.`);
      });
    };
    if (!query.auth_token) {
      // 不存在验证的token
      kickOut();
      return;
    }
    let decoded = {};
    try {
      decoded = jwt.verify(query.auth_token, app.config.jwt.secret);
    } catch (err) {
      if (err) {
        console.error('jwt.verify error:', err);
        kickOut();
        return;
      }
    }
    console.log('--decoded--', decoded);


    // 验证用户信息模块
    let authUser;
    if (decoded.type === 'device') {
      // 设备调用
      authUser = await ctx.service.device.queryOne({ _id: decoded._id });
      console.log('authUser device-----', authUser);
      if (!authUser || authUser.state === 0) {
        kickOut();
        return;
      }
      if (authUser.networkState === 0) {
        // 设备状态改成上线
        authUser.networkState = 1;
        authUser.save();
        ctx.service.sendMsg.sendToUser('MESSAGE', socketMessageConstant.DEVICE_ONLINE(authUser), authUser.org._id, false);
        ctx.service.sendMsg.sendToDeveloper('MESSAGE', socketMessageConstant.DEVICE_ONLINE(authUser), authUser.org._id, false);
      }
      if (authUser.verify !== 1) {
        // 不是一个已经通过审核的设备
        socket.authUser = authUser;
        socket.authType = decoded.type;
        socket.emit('ACK', 'Socket 已经连接，设备还需审核');
        // return;
      }
    } else if (decoded.type === 'platform') {
      // 第三方平台调用。使用开发者账号
      authUser = await ctx.service.developer.queryOne({ _id: decoded._id });
      if (decoded.secretVersion !== authUser.secretVersion) {
        // 密钥版本已经不同
        kickOut();
        return;
      }
    } else {
      // 用户调用
      const queryData = {
        userId: decoded._id,
      };
      authUser = await ctx.service.user.getDetialById(queryData);
    }
    // console.log('authUser**', authUser);
    if (authUser) {
      if (authUser.org.state === 0) {
        // 用户的所属组织已经失效
        kickOut();
        return;
      }
      socket.authUser = authUser;
      socket.authType = decoded.type;
    } else {
      kickOut();
      return;
    }
    console.log('connect user:', authUser);
    ctx.socket.emit('ACK', 'connected!');
    await next();
    // execute when disconnect.
    console.log('--disconnection!---');
    if (decoded.type === 'device') {
      console.log('device off line:', authUser);
      if (authUser.networkState === 1) {
        // 设备状态改成上线
        authUser.networkState = 0;
        authUser.save();
        ctx.service.sendMsg.sendToUser('MESSAGE', socketMessageConstant.DEVICE_OFFLINE(authUser), authUser.org._id, false);
        // 发送给开发者
        ctx.service.sendMsg.sendToDeveloper('MESSAGE', socketMessageConstant.DEVICE_OFFLINE(authUser), authUser.org._id, false);
      }
    }
  };
};
