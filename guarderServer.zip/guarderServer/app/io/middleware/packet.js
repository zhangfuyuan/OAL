'use strict';

module.exports = app => {
  return async (ctx, next) => {
    if (ctx.packet[0] === 'ACK') {
      console.log('client is ACK:', ctx.packet);
    } else {
      ctx.socket.emit('ACK', ctx.packet[1].uuid);
    }
    // console.log('packet is:', ctx.packet, typeof ctx.packet);
    await next();
  };
};
