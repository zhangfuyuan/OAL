'use strict';

const Controller = require('egg').Controller;

class DefaultController extends Controller {
  async index() {
      console.log('000000')
    const { ctx, app } = this;
    const message = ctx.args[0];
    console.log('message--', message)
    await ctx.socket.emit('ACK', `Hi! I've got your message: ${message}`);
  }
  /**
   * 收到了消息接收者的ACK应答
   */
  async ack() {
    const message = this.ctx.args[0];
    console.log('ack message:', message);
    if (message) {
      const wsm = await this.ctx.service.waitSendMq.queryOne({ uuid: message });
      if (wsm) {
        // console.log('wsm------->', wsm);
        wsm.remove();
      }
    }
  }

  async message() {
    const message = this.ctx.args[0];
    console.log('res message:', message);
  }
}
module.exports = DefaultController;
