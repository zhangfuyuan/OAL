'use strict';

const httpProxy = require('./middleware/httpProxyDynamic')
/**
 * @param {Egg.Application} app - egg application
 */
module.exports = app => {
  const { router, controller, middleware, io } = app;
  const userInfo = middleware.authUserInfo(); // app.jwt 之后想要获取登录用户详情的中间件
  const deviceInfo = middleware.deviceInfo();
  const faceFile = middleware.faceImgFile();
  const faceImgMap = async function(path, ctx) {
    // console.log('faceImgMap----', ctx.params);
    const { dataCenter, fid } = ctx.params;
    return `http://127.0.0.1:${dataCenter}/${fid}`;
  };
  const ProxyObj = httpProxy({ asyncMap: faceImgMap });
  router.post('/api/user/signin', controller.user.signin);
  router.get('/api/user/authByToken', app.jwt, userInfo, controller.user.authByToken);
  router.post('/api/user/modifyPsw', app.jwt, middleware.authUserInfo({ psw: true }), controller.user.modifyPsw);
  // 查询本组织内的用户列表
  router.post('/api/user/fetchList', app.jwt, userInfo, controller.user.getUserList);
  // 新增同一组织内的用户
  router.post('/api/user/add', app.jwt, userInfo, controller.user.add);
  // 修改用户信息
  router.post('/api/user/update', app.jwt, userInfo, controller.user.update);
  // 对用户的操作。 action:  delete,  resetPsw
  router.get('/api/user/:userId/:action', app.jwt, userInfo, controller.user.handleOperation);
  // 兼容put方法
  router.put('/api/user/:userId/:action', app.jwt, userInfo, controller.user.handleOperation);
  // 组织信息相关
  // 根据路径获取组织信息
  router.get('/api/org/getByPath/:path', controller.organization.getInfo);
  router.post('/api/org/add', app.jwt, userInfo, controller.organization.add);
  router.post('/api/org/editSaasInfo', app.jwt, userInfo, controller.organization.editSaasInfo);
  router.post('/api/org/fetchList', app.jwt, userInfo, controller.organization.getOrgList);
  router.post('/api/org/update', app.jwt, userInfo, middleware.userPermission({ adminOrg: true }), controller.organization.update);
  router.get('/api/org/:orgId/setState/:state', app.jwt, userInfo, middleware.userPermission({ adminOrg: true }), controller.organization.setState);
  router.put('/api/org/:orgId/setState/:state', app.jwt, userInfo, middleware.userPermission({ adminOrg: true }), controller.organization.setState);
  router.post('/api/org/check/query', app.jwt);
  /** 设备路由相关 */
  router.post('/api/device/register', controller.device.register);
  // 获取设备列表
  router.get('/api/device/list/:verify', app.jwt, userInfo, controller.device.getDeviceList);
  // 设备审核 result -1 不通过， 1 通过
  router.get('/api/device/:deviceId/verify/:result', app.jwt, userInfo, deviceInfo, controller.device.deviceVerify);
  router.put('/api/device/:deviceId/verify/:result', app.jwt, userInfo, deviceInfo, controller.device.deviceVerify);
  router.get('/api/device/:deviceId/remove', app.jwt, userInfo, deviceInfo, controller.device.reomve);
  router.delete('/api/device/:deviceId/remove', app.jwt, userInfo, deviceInfo, controller.device.reomve);
  router.get('/api/device/:deviceId/rename/:name', app.jwt, userInfo, deviceInfo, controller.device.setName);
  router.put('/api/device/:deviceId/rename/:name', app.jwt, userInfo, deviceInfo, controller.device.setName);
  /** end设备路由相关 */
  /** begin face 相关 */
  router.post('/api/face/manage/upload', app.jwt, userInfo, faceFile, controller.face.upload);
  router.post('/api/face/manage/:faceId/upload', app.jwt, userInfo, controller.face.updateImg);
  router.get('/api/face/manage/:faceId/rename/:name', app.jwt, userInfo, controller.face.rename);
  router.post('/api/face/manage/:faceId/modify', app.jwt, userInfo, controller.face.modify);
  router.get('/api/face/manage/:faceId/remove', app.jwt, userInfo, controller.face.remove);
  router.delete('/api/face/manage/:faceId/remove', app.jwt, userInfo, controller.face.remove);
  router.post('/api/face/manage/fetchList', app.jwt, userInfo, controller.face.fetchList);
  router.post('/api/face/attribute/add', app.jwt, userInfo, controller.face.addProfileAttribute);
  router.get('/api/face/attribute/fetch', app.jwt, userInfo, controller.face.getProfileAttribute);
  router.delete('/api/face/attribute/:attributeId/remove', app.jwt, userInfo, controller.face.removeProfileAttribute);
  router.delete('/api/face/manage/removeAll', app.jwt, userInfo, controller.face.removeAll);
  // 更改某个人脸属性
  router.post('/api/face/attribute/update', app.jwt, userInfo, controller.face.updateProfileAttribute);
  router.get('/api/sync/face/:page/:pageSize', app.jwt, userInfo, controller.face.syncFace);
  /**
   * 接受一张图片，识别图片中的人脸
   */
  router.post('/api/face/recognition/img', app.jwt, userInfo, controller.face.recognitionImg);
  router.post('/api/face/recognition/features', app.jwt, userInfo, controller.face.recognitionFeatures);
  /** end face */
  /** begin developer */
  // 获取自己的开发者账号
  router.get('/api/developer/get', app.jwt, userInfo, controller.developer.getDevInfo);
  // 申请生成一个开发者账号信息
  router.get('/api/developer/apply', app.jwt, userInfo, controller.developer.add);
  // 开发者账号认证 key, secret
  router.post('/api/developer/auth', controller.developer.platformAuth);
  // 用旧Token换取一个新token
  router.get('/api/developer/auth/token/refresh', app.jwt, userInfo, controller.developer.refresh);
  // 重置开发者秘钥
  router.get('/api/developer/secret/reset', app.jwt, userInfo, controller.developer.resetSecret);
  /** end developer */

  router.post('/api/aync/access', app.jwt, userInfo, controller.distinguishLog.syncAccess);
  /**
   * 查询报表内容
   */
  router.post('/api/report/fetch', app.jwt, userInfo, controller.distinguishLog.fetch);
  router.get('/api/report/face/:faceId/:date', app.jwt, userInfo, controller.distinguishLog.fetchByFace);
  /**
   * 设置系统一些参数，例如底库大小等
   */
  router.post('/api/sys/setConfig', app.jwt, userInfo, controller.sysConfig.setConfig);
  /**
   * 获取配置信息
   */
  router.get('/api/sys/getConfig', app.jwt, userInfo, controller.sysConfig.getConfig);

  router.get('/faceImg/:dataCenter/:fid', ProxyObj);
  /**
   * socket 相关
   */
  // console.log('origin=================', io.origins);
  // io.origins((origin, callback) => {
  //   console.log('origin=================', origin);
  //   if (origin !== 'https://foo.example.com') {
  //     return callback('origin not allowed', false);
  //   }
  //   callback(null, true);
  // });


  // app.io.of('/chat')
  io.of('/').route('chat', app.io.controller.default.index);
  io.of('/').route('ACK', app.io.controller.default.ack);
  io.of('/').route('MESSAGE', app.io.controller.default.message);
  // 系统路由相关
  router.get('/api/release', controller.home.sysInfo);
  router.get('/*', controller.home.index);
};
