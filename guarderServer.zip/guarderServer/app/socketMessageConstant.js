'use strict';

const result = (code, data) => {
  return { code, entity: data };
};

module.exports = {
  DEVICE_ONLINE: data => result(1000, data), // 门禁设备上线
  DEVICE_OFFLINE: data => result(1001, data), // 门禁设备下线
  DEVICE_KICK_OFF: data => result(1002, data), // 门禁设备踢出下线
  DEVICE_RENAME: data => result(1005, data), // 设备改名称
  DEVICE_REMOVE: data => result(1006, data), // 设备被移除
  DEVICE_APPROVED: data => result(1007, data), // 设备审核不通过
  DEVICE_VERIFIED: data => result(1008, data), // 设备审核通过
  DEVICE_REGISTER: data => result(1009, data), // 设备注册
  DISTINGUISH_LOG: data => result(2004, data), // 考勤识别记录产生
  FACE_ADD: data => result(3000, data), // 新增人脸
  FACE_MODIFY_PROFILE: data => result(3001, data), // 人脸修改资料
  FACE_MODIFY_IMG: data => result(3002, data), // 人脸修改照片
  FACE_REMOVE: data => result(3003, data), // 人脸删除
  FACE_BATCH_ADD: data => result(3004, data), // 人脸批量推送
  FACE_BATCH_REMOVE: data => result(3005, data), // 人脸批量删除
  FACE_REMOVE_ALL: data => result(3006, data), // 人脸批量删除
};
