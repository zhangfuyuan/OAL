'use strict';

const _ = require('lodash');
const Subscription = require('egg').Subscription;

/**
 * 根据要被发送的id获取socket
 * @param {*} sockets
 * @param {*} uid
 */
const getSocketsByUid = (sockets, uid) => {
  const socketList = [];
  if (sockets) {
    for (const p in sockets) {
      if (sockets[p].authUser && sockets[p].authUser._id.toString() === uid.toString()) {
        socketList.push(sockets[p]);
      }
    }
  }
  return socketList;
};

const getOnlineDevice = sockets => {
  // console.log('sockets------>', sockets);
  const sids = [];
  for (const p in sockets) {
    if (sockets[p].authUser) {
      sids.push(sockets[p].authUser._id.toString());
    }
  }
  return sids;
};

class SendMessage extends Subscription {
  // 通过 schedule 属性来设置定时任务的执行间隔等配置
  static get schedule() {
    return {
      interval: '1m', // 1 分钟间隔
      type: 'all', // 指定所有的 worker 都需要执行
    };
  }

  // subscribe 是真正定时任务执行时被运行的函数
  async subscribe() {
    // console.log('----this.app.config.mqMaxSendCount----', this.app.config.mqMaxSendCount);
    const socketIds = getOnlineDevice(this.app.io.sockets.sockets);
    // console.log('socketIds------>', socketIds);
    const queryResult = await this.ctx.service.waitSendMq.queryForSend({ receiverId: { $in: socketIds } });
    // console.log('-------->>>>>>>>', queryResult);
    if (queryResult && queryResult.length > 0) {
      // 还有等待发送的消息在队列中
      for (let i = 0; i < queryResult.length; i++) {
        const item = queryResult[i];
        item.sendCount = (item.sendCount + 1);
        if (item.sendCount >= this.app.config.mqMaxSendCount) {
          console.error('Send MQ error, And remove it:', item);
          await item.remove();
        } else {
          item.lastSendAt = new Date();
          await item.save();
        }
        const sks = getSocketsByUid(this.app.io.sockets.sockets, item.receiverId);
        // console.log('sks------->', sks);
        for (let i = 0; i < sks.length; i++) {
          sks[i].emit(item.key, { data: item.data, uuid: item.uuid, createAt: item.createAt });
        }
      }
    }
    /**
    this.app.io.of('/').clients((error, clients) => {
      if (error) throw error;
      // console.log('clients------', clients);
      for (let i = 0; i < clients.length; i++) {
        // console.log('-----', typeof clients[i]);
        // this.app.io.sockets.sockets[clients[i]].emit('ACK', '34345345345345')
      }
    });
     */
    // console.log('message send:', this.app.io.of('/').clients);
  }
}

module.exports = SendMessage;
