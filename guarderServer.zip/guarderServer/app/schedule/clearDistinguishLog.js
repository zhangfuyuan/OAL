'use strict';

const Subscription = require('egg').Subscription;

class ClearDistinguishLog extends Subscription {
  // 通过 schedule 属性来设置定时任务的执行间隔等配置
  static get schedule() {
    return {
      interval: 1000 * 60 * 60 * 24, // 1 天间隔
      type: 'all', // 指定所有的 worker 都需要执行
    };
  }

  // 查询并删除记录
  async clearRecord(ctx, query) {
    ctx.service.distinguishLog
      .queryAndCount(query).then(async res => {
        const { list } = res;
        for (let i = 0; i < list.length; i++) {
          await list[i].remove();
          // TODO 删除抓拍图片
        }
        if (list.length > 0) {
          this.clearRecord(ctx, query);
        }
      });
  }

  // 清除保存超过三个月的识别记录
  async subscribe() {
    const ctx = this.ctx;
    const t = Date.now() - 1000 * 60 * 60 * 24 * 90;
    const date = new Date(t); // 三个月前的时间点
    const params = {
      query: {
        createAt: {
          $lt: date,
        },
      },
      pageSize: 2, // 每次循环处理两条记录
    };
    this.clearRecord(ctx, params);
  }
}

module.exports = ClearDistinguishLog;
