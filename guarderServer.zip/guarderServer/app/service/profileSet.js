'use strict';

const Service = require('egg').Service;

class ProfileSet extends Service {
  /**
     * 扩展对象
     * @param {*} Profile
  */
  async add(Profile) {
    console.log('add ProfileSet:', Profile);
    const Ps = new this.ctx.model.ProfileSet(Profile);
    return await Ps.save();
  }
  async queryByOrg(org) {
    return await this.ctx.model.ProfileSet.find({ org });
  }
  async query(query = {}) {
    return await this.ctx.model.ProfileSet.findOne(query);
  }
}
module.exports = ProfileSet;
