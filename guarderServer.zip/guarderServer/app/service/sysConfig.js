'use strict';

const Service = require('egg').Service;

class SysConfigService extends Service {
  async add(config) {
    console.log('add SysConfig:', config);
    const sc = new this.ctx.model.SysConfig(config);
    return await sc.save();
  }
  async queryByOrg(org) {
    return await this.ctx.model.SysConfig.find({ org });
  }
  async queryOne(query = {}) {
    return await this.ctx.model.SysConfig.findOne(query);
  }
}
module.exports = SysConfigService;
