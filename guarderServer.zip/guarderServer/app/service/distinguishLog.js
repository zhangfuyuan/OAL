'use strict';

const Service = require('egg').Service;

class distinguishLogService extends Service {
  async add(dl) {
    console.log('add DistinguishLog:', dl);
    const dev = new this.ctx.model.DistinguishLog(dl);
    return await dev.save();
  }
  /**
   * 根据时间范围获取
   * @param {*} begin 开始时间
   * @param {*} end 结束时间
   * @param {*} org 所属组织
   * @param {*} paging { current = 1, pageSize = 15 }
   * @param {*} profileQuery { name, 其他扩展属性 }
   */
  async getAllByDateRanges(begin, end, org, paging, deviceList, profileQuery) {
    // console.log('profileQuery------', profileQuery);
    const query = [
      {
        $match: {
          org,
          deviceTime: { $gt: begin, $lte: end },
          // 'profile.gender': 1,
        },
      },
      {
        $group: {
          _id: {
            faceId: '$faceId',
            deviceDate: '$deviceDate',
          },
          num_tutorial: { $sum: 1 },
          min: { $min: '$deviceTime' },
          max: { $max: '$deviceTime' },
          accessTypes: { $push: '$accessType' },
          device: { $first: '$deviceId' },
          // profile: { $push: '$profile' },
        },
      }];
    if (profileQuery) {
      // 存在对扩展属性的查询
      for (const p in profileQuery) {
        query[0].$match[`profile.${p}`] = profileQuery[p] + '';
        // query[0].$match[`profile.${p}`] = isNaN(profileQuery[p]) ? profileQuery[p] : { $in: [ Number(profileQuery[p]), profileQuery[p] + '' ] };
        // query[0].$match = { ...query[0].$match,  };
      }
    }
    if (deviceList && deviceList.length > 0) {
      query[0].$match.deviceId = { $in: deviceList };
    }
    if (paging) {
      // 需要分页
      const countQuery = [
        {
          $match: {
            org,
            deviceTime: { $gt: begin, $lte: end },
            // 'profile.gender': 1,
          },
        },
        {
          $group: {
            _id: {
              faceId: '$faceId',
              deviceDate: '$deviceDate',
            },
          },
        }];
      if (profileQuery) {
        // 存在对扩展属性的查询
        for (const p in profileQuery) {
          countQuery[0].$match[`profile.${p}`] = profileQuery[p] + '';
          // countQuery[0].$match[`profile.${p}`] = isNaN(profileQuery[p]) ? profileQuery[p] : { $in: [ Number(profileQuery[p]), profileQuery[p] + '' ] };
        }
      }
      const totalList = await this.ctx.model.DistinguishLog.aggregate(countQuery);
      query.push(
        {
          $skip: (paging.current - 1) * paging.pageSize,
        }
      );
      query.push(
        {
          $limit: paging.pageSize,
        }
      );
      // console.log('totalList-----', totalList)
      console.log('query----', JSON.stringify(query));
      let list = await this.ctx.model.DistinguishLog.aggregate(query);
      list = await Promise.all(list.map(async item => {
        // const tempItem = item.toObject();
        // console.log('-------------item----', item._id);
        item.faceInfo = {};
        if (item._id && item._id.faceId) {
          item.faceInfo = await this.ctx.service.face.queryOne({ _id: item._id.faceId });
        }
        item.deviceInfo = await this.ctx.service.device.getById({ _id: item.device });
        return item;
      }));
      return {
        list,
        pagination: {
          current: paging.current,
          pageSize: paging.pageSize,
          total: totalList.length,
        },
      };
    }
    // 不分页，直接给结果
    let reportlist = await this.ctx.model.DistinguishLog.aggregate(query);
    reportlist = await Promise.all(reportlist.map(async item => {
      item.faceInfo = {};
      if (item._id && item._id.faceId) {
        item.faceInfo = await this.ctx.service.face.queryOne({ _id: item._id.faceId });
      }
      item.deviceInfo = await this.ctx.service.device.getById({ _id: item.device });
      return item;
    }));
    return reportlist;
  }

  async query(queryObj = {}) {
    return await this.ctx.model.DistinguishLog.find(queryObj);
  }

  async queryAndCount({ query = {}, pageNo = 1, pageSize = 15 }) {
    const ctx = this.ctx;
    const list = await ctx.model.DistinguishLog
      .find(query)
      .sort({ updateAt: -1 })
      .skip((pageNo - 1) * pageSize)
      .limit(pageSize);
    const total = await ctx.model.DistinguishLog.find(query).countDocuments();
    return {
      list: list || [],
      pagination: {
        pageNo,
        pageSize,
        total,
      },
    };
  }
}
module.exports = distinguishLogService;
