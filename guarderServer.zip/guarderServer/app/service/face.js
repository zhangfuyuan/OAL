'use strict';

const Service = require('egg').Service;
const errorCode = require('../errorCode');
const _ = require('lodash');
const mongoose = require('mongoose');
const socketMessageConstant = require('../socketMessageConstant');

class faceService extends Service {
  async add(faceData) {
    console.log('add face:', faceData);
    const face = new this.ctx.model.Face(faceData);
    return await face.save();
  }

   /**
   * 根据条件获取一条记录
   * @param {*} query 查询条件
   */
  async queryOne(query) {
    return await this.ctx.model.Face.findOne(query);
  }

  async query(query = {}, { current = 1, pageSize = 15 }) {
    const list = await this.ctx.model.Face.find(query).sort({ updateAt: -1 }).limit(pageSize).skip((current - 1) * pageSize);
    const total = await this.ctx.model.Face.find(query).countDocuments();
    return {
      list,
      pagination: {
        current,
        pageSize,
        total,
      },
    };
  }

  /**
   * 检查人脸的属性合法性
   * @param {*} org
   * @param {*} attrList 属性值列表 [ value1, value2, value3 ... ]
   * @param {*} faceId 人脸_id 非必须
   */
  async checkExtendAttr(org, attrList = [], faceId) {
    const attrSettingList = await this.ctx.service.profileSet.queryByOrg(org);
    // console.log('attrList----', attrList);
    let results = errorCode.RESPONE('SUCCESS');
    if (attrSettingList && attrSettingList.length > 0) {
      for (let i = 0; i < attrSettingList.length; i++) {
        if (attrList[i]) {
          // 扩展框有值
          if (attrSettingList[i].componentInfo && attrSettingList[i].componentInfo.type == 2 && attrSettingList[i].componentInfo.data) {
            // 是个选择框
            // 验证值是不是在配置范围以内
            const valueIndex = _.findIndex(attrSettingList[i].componentInfo.data, item => item.value == attrList[i]);
            if (valueIndex === -1) {
              // 写了个值以外的，
              results = errorCode.QUERY_DATA_NO_FOUND;
              break;
            }
          }
          // 验证其他属性
          // 验证唯一性
          if (attrSettingList[i].isUnique) {
            const query = { org, state: 1 };
            query[`profile.${attrSettingList[i].key}`] = attrList[i];
            if (faceId) {
              query._id = {'$ne': mongoose.Types.ObjectId(faceId)}
            }
            const fc = await this.queryOne(query);
            if (fc) {
              // 数据违反唯一约束条件
              console.log('违反唯一约束');
              results = errorCode.DATA_ALREADY_EXISTS;
              break;
            }
          }
        } else {
          // 扩展框无值
          if (attrSettingList[i].required) {
            // 但是这是必填字段
            results = errorCode.DATA_MISSING_PARAMETERS;
            break;
          }
        }
      }
    }
    return results;
  }

  /**
   * 删除所有的
   * @param {*} org 
   */
  async removeAll(org) {
    // 定义最多一次性查询删除10000数据，如果超过则循环遍历删除
    const maxRemoveCount = 10000;
    const total = await this.ctx.model.Face.find({ org, state: 1 }).countDocuments();
    const pageCount = (total + maxRemoveCount - 1) / maxRemoveCount;
    this.ctx.service.sendMsg.sendToDevice('MESSAGE', socketMessageConstant.FACE_REMOVE_ALL({}), org, true);
    this.ctx.service.sendMsg.sendToDeveloper('MESSAGE', socketMessageConstant.FACE_REMOVE_ALL({}), org, true);
    for (let i = 0; i < pageCount; i++) {
      const queryResult = await this.ctx.model.Face.find({ org, state: 1 }, { state: 1 }).limit(maxRemoveCount).skip(i * maxRemoveCount);
      if (queryResult && queryResult.length > 0) {
        // this.ctx.service.sendMsg.sendToDevice('MESSAGE', socketMessageConstant.FACE_BATCH_REMOVE(queryResult.map(item => item._id)), org, true);
        for (let p = 0; p < queryResult.length; p++) {
          queryResult[p].state = 0;
          await queryResult[p].save();
        }
      }
    }
    return total;
  }
}
module.exports = faceService;
