'use strict';

const Service = require('egg').Service;

class deviceService extends Service {
    /**
     * 新增一个设备
     * @param {*} device 设备对象
     */
  async add(device) {
    console.log('add device:', device);
    const dev = new this.ctx.model.Device(device);
    return await dev.save();
  }

  async getByUuidAndOrg({ deviceUuid, org }) {
    return await this.ctx.model.Device.findOne({ deviceUuid, org });
  }

  async getById({ _id }) {
    return await this.ctx.model.Device.findOne({ _id });
  }

  /**
   * 根据条件获取记录
   * @param {*} query 查询条件
   */
  async queryNoPage(query) {
    console.log('query---------', query);
    return await this.ctx.model.Device.find(query);
  }

   /**
   * 根据条件获取一条记录
   * @param {*} query 查询条件
   */
  async queryOne(query) {
    return await this.ctx.model.Device.findOne(query).populate('org');
  }

  /**
   * 根据条件和分页查询设备列表
   * @param opts
   * @param page
   * @param pageSize
   * @returns {Promise<void>}
   */
  async query(query = {}, { current = 1, pageSize = 15 }) {
    const list = await this.ctx.model.Device.find(query).limit(pageSize).skip((current - 1) * pageSize);
    const total = await this.ctx.model.Device.find(query).countDocuments();
    return {
      list,
      pagination: {
        current,
        pageSize,
        total,
      },
    };
  }
}
module.exports = deviceService;
