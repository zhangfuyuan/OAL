'use strict';

const uuid = require('uuid');
/**
 * 发送消息的服务
 */
const Service = require('egg').Service;
const socketMessageConstant = require('../socketMessageConstant');

/**
 * 根据要被发送的id获取socket
 * @param {*} sockets 
 * @param {*} uid 
 */
const getSocketsByUid = (sockets, uid) => {
  const socketList = [];
  if (sockets) {
    for (const p in sockets) {
      // console.log('sockets[p].authUser._id--', sockets[p].authUser, uid);
      if (sockets[p].authUser) {
        // 审核通过的
        if (sockets[p].authUser._id.toString() === uid.toString()) {
          socketList.push(sockets[p]);
        }
      }
    }
  }
  return socketList;
};

class SendMqService extends Service {

  /**
     * 发送socket消息给某个终端
     * @param {*} key 发送的消息key值
     * @param {*} data 要被发送的消息
     * @param {*} receiverId 接受者id
     * @param {*} receiverType 接受者类型
     * @param {*} org 接受者所属组织
     * @param {*} necessary 是否执行消息必达机制
     * @param {*} msgUid 消息的唯一标识
     */
  async send(key = 'MESSAGE', data, receiverId, receiverType, org, necessary, msgUid = uuid.v1()) {
    // const msgUid = uuid.v1();
    console.log('to send msg:', data);
    if (necessary) {
      // 说明需要消息必达
      const Mqbean = new this.ctx.model.WaitSendMq({
        uuid: msgUid, data, receiverId, receiverType, org, key,
      });
      await Mqbean.save();
    }
    const socketMaps = getSocketsByUid(this.app.io.sockets.sockets, receiverId);
    // console.log('socketMaps------', socketMaps);
    if (socketMaps && socketMaps.length > 0) {
      socketMaps.forEach(item => {
        console.log('socket client is:', item.id);
        item.emit(key, { uuid: msgUid, data, createAt: new Date() });
      });
    }
  }

  async addToMq(key = 'MESSAGE', data, receiverId, receiverType, org, msgUid = uuid.v1()) {
    const Mqbean = new this.ctx.model.WaitSendMq({
      uuid: msgUid, data, receiverId, receiverType, org, key,
    });
    await Mqbean.save();
  }

  async sendToDevice(key = 'MESSAGE', data, org, necessary) {
    // 只筛选出状态正常，且已经审核通过的设备
    const deviceList = await this.ctx.service.device.queryNoPage({ org, state: 1, verify: 1 });
    console.log('sendToDevice deviceList--', deviceList);
    deviceList.forEach(item => {
      // this.send(key, data, item._id.toString(), 'device', org, necessary, uuid.v1());
      this.addToMq(key, data, item._id.toString(), 'device', org);
    });
  }
  async sendToUser(key = 'MESSAGE', data, org, necessary) {
    const userList = await this.ctx.service.user.queryAll({ org, state: 1 });
    console.log('sendToDevice userList--', userList);
    userList.forEach(item => {
      this.send(key, data, item._id.toString(), 'user', org, necessary, uuid.v1());
    });
  }

  async sendToDeveloper(key = 'MESSAGE', data, org, necessary) {
    const dev = await this.ctx.service.developer.getByOrg(org);
    console.log('sendToDev dev--', dev);
    if (dev) {
      if (necessary) {
        this.addToMq(key, data, dev._id.toString(), 'platform', org);
      } else {
        this.send(key, data, dev._id.toString(), 'platform', org, necessary, uuid.v1());
      }
    }
  }

  async sendToDeviceById(key = 'MESSAGE', deviceId, org, pageSize = 100) {
    const total = await this.ctx.model.Face.find({ org: org._id, state: 1 }).countDocuments();
    const pageCount = (total + pageSize - 1) / pageSize;
    for (let i = 0; i < pageCount; i++) {
      const list = await this.ctx.model.Face.find({ org: org._id, state: 1 }).limit(pageSize).skip(i * pageSize);
      if (list && list.length > 0) {
        const tempList = list.map(item => {
          item = item.toObject();
          if (item.fileInfo && item.fileInfo.url) {
            const tempData = item.fileInfo.url.split(':');
            item.imgPath = `/faceImg/${tempData[1]}/${item.fileName}`;
          }
          return item;
        });
        this.send(key, socketMessageConstant.FACE_BATCH_ADD(tempList), deviceId.toString(), 'device', org._id, true, uuid.v1());
      }
    }
  }

  /**
   * 直接向设备发送一条消息
   * @param {*} key 
   * @param {*} deviceId 
   * @param {*} org 
   * @param {*} msg 
   */
  async sendMsgToDevice(key = 'MESSAGE', deviceId, org, msg) {
    this.send(key, msg, deviceId.toString(), 'device', org._id, true, uuid.v1());
  }

  async getScoketClientById(receiverId) {
    return getSocketsByUid(this.app.io.sockets.sockets, receiverId);
  }
}
module.exports = SendMqService;
