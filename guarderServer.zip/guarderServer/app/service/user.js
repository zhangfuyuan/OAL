'use strict';

const Service = require('egg').Service;

class UserService extends Service {
  /**
   * 根据用户名查询用户
   * @param userName
   * @param org
   * @return {Promise<TSchema>}
   */
  async getByUserName(userName, org) {
    return await this.ctx.model.User.findOne({ userName, org, state: 1 }).populate('org');
  }

  /**
   * 根据 _id 获取用户详情
   * @param userId
   * @param psw
   * @return {Promise<void>}
   */
  async getDetialById({ userId, psw }) {
    if (psw) {
      return await this.ctx.model.User.findOne({ _id: userId }).populate('org');
    }
    return await this.ctx.model.User.findOne({ _id: userId }, { password: 0 }).populate('org');
  }

  /**
   * 根据用户名获取基础信息
   * @param userName
   * @param org
   * @return {Promise<TSchema>}
   */
  async getBaseInfoByUserName(userName, org) {
    return await this.ctx.model.User.findOne({ userName, org, state: 1 }, { password: 0 });
  }
  /**
   * 新增用户
   * @param userBean
   * @return {Promise<WriteOpResult | this>}
   */
  async add(userBean) {
    console.log('addUser:', userBean);
    const User = new this.ctx.model.User(userBean);
    // User.save().catch(er => console.log('error is:', er));
    // return userBean;
    return await User.save();
  }
  
/**
 * 根据查询条件返回一条数据
 * @param {*} query 查询条件
 */
  async queryOne(query = {}) {
    return await this.ctx.model.User.findOne(query, { password: 0 });
  }

  /***
   * 根据条件，不分页查询出所有有用户
   */
  async queryAll(query = {}) {
    return await this.ctx.model.User.find(query, { password: 0 });
  }
/**
 * 根据条件查询用户列表
 * @param {*} query 查询条件
 * @param {*} param1 分页条件
 */
  async query(query = {}, { current = 1, pageSize = 15 }) {
    const list = await this.ctx.model.User.find(query).limit(pageSize).skip((current - 1) * pageSize);
    const total = await this.ctx.model.User.find(query).count();
    return {
      list,
      pagination: {
        current,
        pageSize,
        total,
      },
    };
  }
}
module.exports = UserService;
