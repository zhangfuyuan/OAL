'use strict';

const Service = require('egg').Service;

class OrgService extends Service {
  /**
   * 新增组织
   * @param orgBean
   * @returns {Promise<WriteOpResult | this>}
   */
  async add(orgBean) {
    console.log('add Organization:', orgBean);
    const Org = new this.ctx.model.Organization(orgBean);
    return await Org.save();
  }
  async getByPath(path) {
    return await this.ctx.model.Organization.findOne({ path });
  }
  async getById(_id) {
    return await this.ctx.model.Organization.findOne({ _id });
  }

  /**
   * 获取代理商信息
   * @returns {Promise<TSchema>}
   */
  async getAgent() {
    return await this.ctx.model.Organization.findOne({ type: 0 });
  }

   /**
   * 根据条件获取一条记录
   * @param {*} query 查询条件
   */
  async queryOne(query) {
    return await this.ctx.model.Device.Organization(query);
  }

  /**
   * 根据条件和分页查询组织列表
   * @param opts
   * @param page
   * @param pageSize
   * @returns {Promise<void>}
   */
  async query(query = {}, { current = 1, pageSize = 15 }) {
    const list = await this.ctx.model.Organization.find(query).limit(pageSize).skip((current - 1) * pageSize);
    const total = await this.ctx.model.Organization.find(query).countDocuments();
    const resultList = [];
    for (let item of list) {
      const orgAdmin = await this.ctx.model.User.findOne({ org: item._id, type: 0 });
      // console.log(item, '==orgAdmin-----', orgAdmin);
      item = item.toObject();
      item.contact = orgAdmin.profile;
      resultList.push(item);
    }
    return {
      list: resultList,
      pagination: {
        current,
        pageSize,
        total,
      },
    };
  }
}
module.exports = OrgService;
