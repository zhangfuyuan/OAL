'use strict';

const Service = require('egg').Service;

class developerService extends Service {
  async add(deve) {
    console.log('add developer:', deve);
    const Deve = new this.ctx.model.Developer(deve);
    return await Deve.save();
  }
  /**
   * 根据条件获取一条记录
   * @param {*} query 查询条件
   */
  async queryOne(query) {
    return await this.ctx.model.Developer.findOne(query).populate('org');
  }
  async getByOrg(org) {
    return await this.ctx.model.Developer.findOne({ org });
  }
}
module.exports = developerService;
