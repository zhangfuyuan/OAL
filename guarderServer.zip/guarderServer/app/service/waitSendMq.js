'use strict';

const Service = require('egg').Service;

class waitSendMqService extends Service {
  async add(mq) {
    console.log('add mq:', mq);
    const Mqbean = new this.ctx.model.WaitSendMq(mq);
    return await Mqbean.save();
  }
  /**
   * 根据条件获取一条记录
   * @param {*} query 查询条件
   */
  async queryOne(query) {
    return await this.ctx.model.WaitSendMq.findOne(query);
  }
  /**
   * 查询消息队列列表
   * @param {*} query 查询条件
   */
  async query(query = {}) {
    return await this.ctx.model.WaitSendMq.find(query).sort({ lastSendAt: 1 });
  }
  async remove(query = {}) {
    return await this.ctx.model.WaitSendMq.remove(query);
  }
  /**
   * 查询消息队列列表
   * @param {*} query 查询条件
   */
  async queryForSend(query = {}) {
    return await this.ctx.model.WaitSendMq.find(query).sort({ lastSendAt: 1 }).limit(500);
  }
}
module.exports = waitSendMqService;
