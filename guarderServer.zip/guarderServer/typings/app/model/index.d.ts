// This file is created by egg-ts-helper@1.25.6
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportDeveloper = require('../../../app/model/developer');
import ExportDevice = require('../../../app/model/device');
import ExportDistinguishLog = require('../../../app/model/distinguishLog');
import ExportFace = require('../../../app/model/face');
import ExportFacePackage = require('../../../app/model/facePackage');
import ExportOrganization = require('../../../app/model/organization');
import ExportProfileSet = require('../../../app/model/profileSet');
import ExportSysConfig = require('../../../app/model/sysConfig');
import ExportUser = require('../../../app/model/user');
import ExportWaitSendMq = require('../../../app/model/waitSendMq');

declare module 'egg' {
  interface IModel {
    Developer: ReturnType<typeof ExportDeveloper>;
    Device: ReturnType<typeof ExportDevice>;
    DistinguishLog: ReturnType<typeof ExportDistinguishLog>;
    Face: ReturnType<typeof ExportFace>;
    FacePackage: ReturnType<typeof ExportFacePackage>;
    Organization: ReturnType<typeof ExportOrganization>;
    ProfileSet: ReturnType<typeof ExportProfileSet>;
    SysConfig: ReturnType<typeof ExportSysConfig>;
    User: ReturnType<typeof ExportUser>;
    WaitSendMq: ReturnType<typeof ExportWaitSendMq>;
  }
}
