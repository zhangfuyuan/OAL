// This file is created by egg-ts-helper@1.25.6
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportDeveloper = require('../../../app/service/developer');
import ExportDevice = require('../../../app/service/device');
import ExportDistinguishLog = require('../../../app/service/distinguishLog');
import ExportFace = require('../../../app/service/face');
import ExportOrganization = require('../../../app/service/organization');
import ExportProfileSet = require('../../../app/service/profileSet');
import ExportSeaweed = require('../../../app/service/seaweed');
import ExportSendMsg = require('../../../app/service/sendMsg');
import ExportSysConfig = require('../../../app/service/sysConfig');
import ExportUser = require('../../../app/service/user');
import ExportWaitSendMq = require('../../../app/service/waitSendMq');

declare module 'egg' {
  interface IService {
    developer: ExportDeveloper;
    device: ExportDevice;
    distinguishLog: ExportDistinguishLog;
    face: ExportFace;
    organization: ExportOrganization;
    profileSet: ExportProfileSet;
    seaweed: ExportSeaweed;
    sendMsg: ExportSendMsg;
    sysConfig: ExportSysConfig;
    user: ExportUser;
    waitSendMq: ExportWaitSendMq;
  }
}
