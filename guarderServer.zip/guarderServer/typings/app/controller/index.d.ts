// This file is created by egg-ts-helper@1.25.6
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportDeveloper = require('../../../app/controller/developer');
import ExportDevice = require('../../../app/controller/device');
import ExportDistinguishLog = require('../../../app/controller/distinguishLog');
import ExportFace = require('../../../app/controller/face');
import ExportHome = require('../../../app/controller/home');
import ExportOrganization = require('../../../app/controller/organization');
import ExportSysConfig = require('../../../app/controller/sysConfig');
import ExportUser = require('../../../app/controller/user');

declare module 'egg' {
  interface IController {
    developer: ExportDeveloper;
    device: ExportDevice;
    distinguishLog: ExportDistinguishLog;
    face: ExportFace;
    home: ExportHome;
    organization: ExportOrganization;
    sysConfig: ExportSysConfig;
    user: ExportUser;
  }
}
