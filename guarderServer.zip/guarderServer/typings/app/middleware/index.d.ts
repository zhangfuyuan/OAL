// This file is created by egg-ts-helper@1.25.6
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAuthUserInfo = require('../../../app/middleware/authUserInfo');
import ExportDeviceInfo = require('../../../app/middleware/deviceInfo');
import ExportFaceImgFile = require('../../../app/middleware/faceImgFile');
import ExportFaceSdk = require('../../../app/middleware/faceSdk');
import ExportUserPermission = require('../../../app/middleware/userPermission');
import ExportHttpProxyDynamicIndex = require('../../../app/middleware/httpProxyDynamic/index');

declare module 'egg' {
  interface IMiddleware {
    authUserInfo: typeof ExportAuthUserInfo;
    deviceInfo: typeof ExportDeviceInfo;
    faceImgFile: typeof ExportFaceImgFile;
    faceSdk: typeof ExportFaceSdk;
    userPermission: typeof ExportUserPermission;
    httpProxyDynamic: {
      index: typeof ExportHttpProxyDynamicIndex;
    }
  }
}
