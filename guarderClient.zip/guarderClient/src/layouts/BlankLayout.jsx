import React from 'react';

const Layout = ({ children }) => <div>{children}</div>;

export default Layout;
